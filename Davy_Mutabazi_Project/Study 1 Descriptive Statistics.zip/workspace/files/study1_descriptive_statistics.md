# Study 1 Descriptive Statistics

Sample standard deviations (N−1 denominator); all values are rounded to two decimal places.

| Variable | N | Mean | Standard Deviation | Minimum | Maximum |
|---|---:|---:|---:|---:|---:|
| AVO1 | 302 | 2.21 | 0.79 | 1.00 | 5.50 |
| AVO2 | 302 | 2.26 | 0.94 | 1.00 | 6.39 |
| PARPOS | 302 | 0.82 | 0.51 | 0.05 | 5.00 |
| OUTPOS | 302 | 0.85 | 0.51 | 0.00 | 2.75 |
| PA_MEAN | 302 | 4.73 | 0.96 | 1.75 | 7.00 |
