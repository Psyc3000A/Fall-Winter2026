// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    },
    {
      "type": "lab.plugins.Transmit",
      "url": "\u002Fsave",
      "encoding": "form",
      "updates": {
        "incremental": false
      },
      "callbacks": {
        "setup": function(){this.headers["X-CSRFToken"]=window.csrf_token},
        "full": function(e){e&&e.ok&&(window.location="/next")}
      },
      "path": undefined
    }
  ],
  "metadata": {
    "title": "",
    "description": "",
    "repository": "",
    "contributors": ""
  },
  "messageHandlers": {},
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.flow.Sequence",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "before:prepare": function anonymous(
) {
rewprob = 0.8
hr_tl_br = 1 // HighRew (hr) is top left (tl) and bottom right (br)
tl_br = 0
x = 0
z = 0 // Error Variable Timeout
highrew = 0 // 1 if sequence stimulus is high reward prob, 0 otherwise, defined @ "random number", or "Abfrage 2ter Tastendruck" for Joker Trials
i = 0 // 1 if person corrected incorrectly
this.parameters.p = Array([0]) // no. of points received
h = 0
n = 0
q = 0
o = 0
w = 0 // additional screen time in FP condition
}
      },
      "title": "Grp1 Day2:1",
      "content": [
        {
          "type": "lab.flow.Sequence",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "Instruction",
          "content": [
            {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Description",
              "content": [
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -25,
                      "angle": 0,
                      "width": 516.43,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Hello and welcome to day two of our experiment!",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 526.15,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -25,
                      "angle": 0,
                      "width": 353.9,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Please press F11 for Full Screen.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction F11"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -25,
                      "angle": 0,
                      "width": 546.65,
                      "height": 58.58,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Please eliminate all possible sources of distraction, \nand refrain from listening to music.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 526.15,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction Störquellen"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -25,
                      "angle": 0,
                      "width": 584.4,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Today's experiment will take around 75 minutes in total.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 464.24,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction: Dauer"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -25,
                      "angle": 0,
                      "width": 574.61,
                      "height": 58.58,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Your task is identical to yesterday's.\nWe will now quickly go over the most important points.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": 0,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -112,
                      "angle": 0,
                      "width": 747.96,
                      "height": 121.5,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Just like yesterday, it is your task to collect as many points as possible.\n\nThe points are counted in the background.\nYour bonus payout increases with each collected point.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "no1eurocoin.png": "embedded\u002F95d63f46dcb769bd416c2cc782f5c6def0fbeb89d3740e3196c6a5ae06e4553a.png"
                  },
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction Punkte sammeln"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -175,
                      "angle": 0,
                      "width": 569.11,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "The probabilities of winning a point are the same as yesterday.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -89,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -89,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                    "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
                  },
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction Reward Probs 1",
                  "tardy": true,
                  "skip": "${hr_tl_br == 0}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -175,
                      "angle": 0,
                      "width": 569.11,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "The chances of winning will not change throughout the experiment.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 526.14,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "image",
                      "left": "100",
                      "top": "-37",
                      "angle": 0,
                      "width": "55",
                      "height": "44.95",
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": "-90",
                      "top": "37",
                      "angle": 0,
                      "width": "55",
                      "height": "44.95",
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": "-90",
                      "top": "-37",
                      "angle": 0,
                      "width": "55",
                      "height": "44.95",
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": "100",
                      "top": "37",
                      "angle": 0,
                      "width": "55",
                      "height": "44.95",
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                    "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
                  },
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction Reward Probs 2",
                  "tardy": true,
                  "skip": "${hr_tl_br == 1}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -175,
                      "angle": 0,
                      "width": 679.68,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "The chances of winning will not change throughout the experiment.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -89,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -89,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                    "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
                  },
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction Reward Probs 1",
                  "tardy": true,
                  "skip": "${hr_tl_br == 0}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -175,
                      "angle": 0,
                      "width": 679.68,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "The chances of winning will not change throughout the experiment.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 526.14,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "image",
                      "left": "100",
                      "top": "-37",
                      "angle": 0,
                      "width": "55",
                      "height": "44.95",
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": "-90",
                      "top": "37",
                      "angle": 0,
                      "width": "55",
                      "height": "44.95",
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": "-90",
                      "top": "-37",
                      "angle": 0,
                      "width": "55",
                      "height": "44.95",
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": "100",
                      "top": "37",
                      "angle": 0,
                      "width": "55",
                      "height": "44.95",
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                    "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
                  },
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction Reward Probs 2",
                  "tardy": true,
                  "skip": "${hr_tl_br == 1}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -225,
                      "angle": 0,
                      "width": 670.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "You now have again the possibilities to practice some test runs.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -25,
                      "angle": 0,
                      "width": 816.06,
                      "height": 63.46,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#d6341a",
                      "text": "Just like yesterday, when two circles appear you should always try \nto choose the key with the higher chance of winning a point!",
                      "fontStyle": "normal",
                      "fontWeight": "bold",
                      "fontSize": "26",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 239,
                      "angle": 0,
                      "width": 373.8,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press any key to start the test runs.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 21.34,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#ffffff",
                      "text": "S",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 21.34,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#ffffff",
                      "text": "X",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 21.34,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#ffffff",
                      "text": "K",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 26.66,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#ffffff",
                      "text": "M",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 250,
                      "top": -100,
                      "angle": 0,
                      "width": 106.56,
                      "height": 27.12,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#ffffff",
                      "text": "right hand",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": -250,
                      "top": -100,
                      "angle": 0,
                      "width": 92.38,
                      "height": 27.12,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "left hand",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": -250,
                      "top": -36,
                      "angle": 0,
                      "width": 137.26,
                      "height": 27.12,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "middle finger",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": -250,
                      "top": 36,
                      "angle": 0,
                      "width": 123.24,
                      "height": 27.12,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "index finger",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 250,
                      "top": -36,
                      "angle": 0,
                      "width": 137.26,
                      "height": 27.12,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "middle finger",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 250,
                      "top": 36,
                      "angle": 0,
                      "width": 123.24,
                      "height": 27.12,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "index finger",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -214,
                      "angle": 0,
                      "width": 471.17,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#ffffff",
                      "text": "Don't forget the key assignments:",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction key assignment"
                }
              ]
            },
            {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Countdown Instructions",
              "content": [
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": "125",
                      "top": "-25",
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 15.57,
                      "height": 31.64,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "5",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "28",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {},
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction_Countdown",
                  "timeout": "1000"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": "125",
                      "top": "-25",
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 15.57,
                      "height": 31.64,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "4",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "28",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {},
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction_Countdown",
                  "timeout": "1000"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": "125",
                      "top": "-25",
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 15.57,
                      "height": 31.64,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "3",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "28",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {},
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction_Countdown",
                  "timeout": "1000"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": "125",
                      "top": "-25",
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 15.57,
                      "height": 31.64,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "2",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "28",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {},
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction_Countdown",
                  "timeout": "1000"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": "125",
                      "top": "-25",
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 15.57,
                      "height": 31.64,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "1",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "28",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {},
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction_Countdown",
                  "timeout": "1000"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": "125",
                      "top": "-25",
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 15.57,
                      "height": 31.64,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "0",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "28",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {},
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction_Countdown",
                  "timeout": "1000"
                }
              ]
            },
            {
              "type": "lab.flow.Loop",
              "templateParameters": [
                {
                  "position_x": "95",
                  "position_y": "-36",
                  "position_x2": "0",
                  "position_y2": "0"
                },
                {
                  "position_x": "-95",
                  "position_y": "36",
                  "position_x2": "0",
                  "position_y2": "0"
                },
                {
                  "position_x": "95",
                  "position_y": "36",
                  "position_x2": "0",
                  "position_y2": "0"
                },
                {
                  "position_x": "95",
                  "position_y": "-36",
                  "position_x2": "0",
                  "position_y2": "0"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "0",
                  "position_y2": "0"
                },
                {
                  "position_x": "95",
                  "position_y": "36",
                  "position_x2": "0",
                  "position_y2": "0"
                },
                {
                  "position_x": "-95",
                  "position_y": "36",
                  "position_x2": "0",
                  "position_y2": "0"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "0",
                  "position_y2": "0"
                },
                {
                  "position_x": "-95",
                  "position_y": "36",
                  "position_x2": "0",
                  "position_y2": "0"
                },
                {
                  "position_x": "95",
                  "position_y": "-36",
                  "position_x2": "0",
                  "position_y2": "0"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "0",
                  "position_y2": "0"
                },
                {
                  "position_x": "95",
                  "position_y": "-36",
                  "position_x2": "0",
                  "position_y2": "0"
                },
                {
                  "position_x": "-95",
                  "position_y": "36",
                  "position_x2": "0",
                  "position_y2": "0"
                },
                {
                  "position_x": "95",
                  "position_y": "36",
                  "position_x2": "0",
                  "position_y2": "0"
                },
                {
                  "position_x": "95",
                  "position_y": "-36",
                  "position_x2": "0",
                  "position_y2": "0"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "-36"
                },
                {
                  "position_x": "95",
                  "position_y": "36",
                  "position_x2": "0",
                  "position_y2": "0"
                },
                {
                  "position_x": "-95",
                  "position_y": "36",
                  "position_x2": "0",
                  "position_y2": "0"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "0",
                  "position_y2": "0"
                }
              ],
              "sample": {
                "mode": "sequential",
                "n": ""
              },
              "files": {
                "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                "no1eurocoin.png": "embedded\u002F95d63f46dcb769bd416c2cc782f5c6def0fbeb89d3740e3196c6a5ae06e4553a.png",
                "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png"
              },
              "responses": {},
              "parameters": {},
              "messageHandlers": {},
              "title": "instruction trials",
              "shuffleGroups": [],
              "template": {
                "type": "lab.flow.Sequence",
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "Trials",
                "content": [
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "rect",
                        "left": 75,
                        "top": 50,
                        "angle": 0,
                        "width": 1582.18,
                        "height": 810.26,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black"
                      },
                      {
                        "type": "i-text",
                        "left": -12,
                        "top": 0,
                        "angle": 0,
                        "width": 815.69,
                        "height": 152.96,
                        "stroke": "#ffffff",
                        "strokeWidth": 0,
                        "fill": "#ffffff",
                        "text": "${ z == 1 || q == 1 || i  == 1 ? k = 800 : k = 600 }\n${ r = Math.random() }\n\n${tl_br = ( (parameters.position_x == '95' && parameters.position_y == '36') ||\n(parameters.position_x == '-95' && parameters.position_y == '-36')) ? 1 : 0}",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": "24",
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {},
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "random number",
                    "tardy": true,
                    "skip": true
                  },
                  {
                    "type": "lab.flow.Sequence",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "Single Thin Green",
                    "skip": "${ parameters.position_x2 != 0 }",
                    "tardy": true,
                    "content": [
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "10000",
                            "height": "10000",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"Background.PNG\"] }"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x }",
                            "top": "${ parameters.position_y }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "Background.PNG": "embedded\u002Ff6e74e440a74dbed53dbea3dfe3e6d9e7676ed25544b5f21e65d1ba6576cd36c.PNG"
                        },
                        "responses": {
                          "keypress(s)": "-95 -36",
                          "keypress(x)": "-95 36",
                          "keypress(k)": "95 -36",
                          "keypress(m)": "95 36",
                          "keypress(S)": "-95 -36",
                          "keypress(X)": "-95 36",
                          "keypress(K)": "95 -36",
                          "keypress(M)": "95 36"
                        },
                        "parameters": {},
                        "messageHandlers": {
                          "before:prepare": function anonymous(
) {
highrew = (hr_tl_br == 1 && tl_br == 1) || (hr_tl_br == 0 && tl_br == 0)  ? 1 : 0
}
                        },
                        "title": "Stimulus",
                        "timeout": "${k}",
                        "correctResponse": "${ parameters.position_x } ${ parameters.position_y }",
                        "tardy": true
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": "#ffffff",
                            "strokeWidth": 1,
                            "fill": "#000000"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 125.39,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Too slow",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -175,
                            "angle": 0,
                            "width": 977.28,
                            "height": 78.11,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on  == 'response' && state.correct ? x = 0 : x = x + 1 }\n${ state.ended_on == 'skipped' ? x = x - 1 : x = x }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": 32,
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Zu Schnell\u002Flangsam",
                        "skip": "${ state.ended_on !== 'timeout' }",
                        "tardy": true,
                        "timeout": "1200"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 150,
                            "top": 50,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 489.51,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "${ state.ended_on == 'timeout' ? z = 1 : z = 0 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Addition",
                        "timeout": "1000",
                        "tardy": true,
                        "skip": true
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 154.74,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Wrong key!",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                          "no1eurocoin.png": "embedded\u002F95d63f46dcb769bd416c2cc782f5c6def0fbeb89d3740e3196c6a5ae06e4553a.png",
                          "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png"
                        },
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "no reward",
                        "timeout": "1200",
                        "tardy": true,
                        "skip": "${ z == 1 || state.correct }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x }",
                            "top": "${ parameters.position_y }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -150,
                            "angle": 0,
                            "width": 634.91,
                            "height": 36.16,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'timeout' ? i = 1 : i = 0 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": 32,
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"smiley_small_green.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "1eurocoin.png": "embedded\u002F7f759ca75bdc64bef84579d85e9384c3c4059b4aa80415ebd58b8b2e5defb010.png",
                          "smiley_small_green.png": "embedded\u002F461ff38348b0701b6add328b041b0d329602f61238f1427d5a0575b0536093d8.png"
                        },
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Reward",
                        "timeout": "400",
                        "tardy": true,
                        "skip": "${ z == 1 || (state.correct == 1) == 0 || (highrew == 0 && r \u003C= rewprob) || (highrew == 1 && r \u003E= rewprob)}"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -150,
                            "angle": 0,
                            "width": 710.55,
                            "height": 36.16,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'timeout' ? this.parameters.p[0]++ : this.parameters.p[0] = this.parameters.p[0] }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": 32,
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"smiley_small_green.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "1eurocoin.png": "embedded\u002F7f759ca75bdc64bef84579d85e9384c3c4059b4aa80415ebd58b8b2e5defb010.png",
                          "smiley_small_green.png": "embedded\u002F461ff38348b0701b6add328b041b0d329602f61238f1427d5a0575b0536093d8.png"
                        },
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "ITI rew",
                        "timeout": "100",
                        "tardy": true,
                        "skip": "${ state.ended_on == 'skipped'}"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x }",
                            "top": "${ parameters.position_y }",
                            "angle": 0,
                            "width": "50",
                            "height": 19.2,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"frowny_small_red.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png",
                          "frowny_small_red.png": "embedded\u002F75fcaf37aa5bd8004458100177b49f7d494b504f1fe5c8468fad8d2e53937f64.png"
                        },
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "White Point",
                        "timeout": "400",
                        "tardy": true,
                        "skip": "${ z == 1 || (state.correct == 1) == 0 || (highrew == 0 && r \u003E rewprob) || (highrew == 1 && r \u003C rewprob)}"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"frowny_small_red.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                          "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png",
                          "frowny_small_red.png": "embedded\u002F75fcaf37aa5bd8004458100177b49f7d494b504f1fe5c8468fad8d2e53937f64.png"
                        },
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "ITI norew",
                        "timeout": "100",
                        "tardy": true,
                        "skip": "${ state.ended_on == 'skipped'}"
                      }
                    ]
                  },
                  {
                    "type": "lab.flow.Sequence",
                    "files": {},
                    "responses": {},
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "Joker Thin Green",
                    "tardy": true,
                    "skip": "${ parameters.position_x2 == 0}",
                    "content": [
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 150,
                            "top": 63,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 956.31,
                            "height": 215.88,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "${ a = parameters.position_x.toString() } ${ b = parameters.position_y.toString() }\n${ Leer = ' ' }\n${ R1 = a.concat(Leer, b) }\n${ x2 = parameters.position_x2.toString() } ${ y2 = parameters.position_y2.toString() }\n${ R2 = x2.concat(Leer, y2) }\n\n${ (R1 == '-95 -36' && R2 == '95 36') || (R1 == '-95 36' && R2 == '95 -36') ? m = 0 : m = 1 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Correct responses",
                        "tardy": true,
                        "skip": true
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 10001.1,
                            "height": 10000.54,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"Background.PNG\"] }"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x }",
                            "top": "${ parameters.position_y }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x2 }",
                            "top": "${ parameters.position_y2 }",
                            "angle": 0,
                            "width": "50",
                            "height": 46.76,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "Background.PNG": "embedded\u002Ff6e74e440a74dbed53dbea3dfe3e6d9e7676ed25544b5f21e65d1ba6576cd36c.PNG"
                        },
                        "responses": {
                          "keypress(s)": "-95 -36",
                          "keypress(x)": "-95 36",
                          "keypress(k)": "95 -36",
                          "keypress(m)": "95 36",
                          "keypress(S)": "-95 -36",
                          "keypress(X)": "-95 36",
                          "keypress(K)": "95 -36",
                          "keypress(M)": "95 36"
                        },
                        "parameters": {},
                        "messageHandlers": {
                          "before:prepare": function anonymous(
) {
highrew = (hr_tl_br == 1 && tl_br == 1) || (hr_tl_br == 0 && tl_br == 0)  ? 1 : 0
}
                        },
                        "title": "Stimulus_Joker",
                        "timeout": "${k}",
                        "tardy": true
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x }",
                            "top": "${ parameters.position_y }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x2 }",
                            "top": "${ parameters.position_y2 }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -225,
                            "angle": 0,
                            "width": 672.89,
                            "height": 184.42,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "\n${state.response == R1 || state.response == R2 ? y = 1 : y = 0 }\n ${ state.ended_on == 'timeout' ? y = 0 : y = y }\n\n${ y == 1 ? x = 0 : x = x + 1 }\n${ state.ended_on == 'skipped' ? x = x - 1 : x = x }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "i-text",
                            "left": -10,
                            "top": 162,
                            "angle": 0,
                            "width": 912.19,
                            "height": 121.5,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'timeout' ? f = 0 : f = 1 }\n${ state.response == '95 -36' || state.response == '-95 36' ? highrew = 0 : highrew = 1 }\n\n${hr_tl_br == 1 ? highrew=highrew : highrew = !highrew}",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {
                          "keypress": "Second Press"
                        },
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Abfrage 2ter Tastendruck",
                        "timeout": "40",
                        "tardy": true,
                        "skip": "${ state.ended_on == 'timeout' }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": "#ffffff",
                            "strokeWidth": 1,
                            "fill": "#000000"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 464.27,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Please only press one key at a time.",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Doppelter Tastendruck",
                        "skip": "${ state.ended_on != 'response' }",
                        "tardy": true,
                        "timeout": "1200"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": "#ffffff",
                            "strokeWidth": 1,
                            "fill": "#000000"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 125.39,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Too slow",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "i-text",
                            "left": 25,
                            "top": -136,
                            "angle": 0,
                            "width": 492.21,
                            "height": 27.12,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'timeout' ? q = 1 : q = 0 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Zu Schnell\u002Flangsam",
                        "skip": "${ f == 1 }",
                        "tardy": true,
                        "timeout": "1000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 150,
                            "top": 63,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 537.03,
                            "height": 90.04,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "${ state.ended_on == 'timeout' ? z = 1 : z = 0 }\n${ y == 1 && m == 1 && highrew == 0 ? n = n + 1 : n = n }\n${ y == 1 && m == 1 && highrew == 1 ? h = h + 1 : h = h }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Addition",
                        "timeout": "1000",
                        "tardy": true,
                        "skip": true
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 154.74,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Wrong key!",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                          "no1eurocoin.png": "embedded\u002F95d63f46dcb769bd416c2cc782f5c6def0fbeb89d3740e3196c6a5ae06e4553a.png",
                          "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png"
                        },
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "no reward",
                        "timeout": "1200",
                        "tardy": true,
                        "skip": "${ z == 1 || y == 1 || q == 1 }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x }",
                            "top": "${ parameters.position_y }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x2 }",
                            "top": "${ parameters.position_y2 }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -125,
                            "angle": 0,
                            "width": 634.91,
                            "height": 36.16,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'timeout' ? i = 1 : i = 0 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": 32,
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"smiley_small_green.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "1eurocoin.png": "embedded\u002F7f759ca75bdc64bef84579d85e9384c3c4059b4aa80415ebd58b8b2e5defb010.png",
                          "smiley_small_green.png": "embedded\u002F461ff38348b0701b6add328b041b0d329602f61238f1427d5a0575b0536093d8.png"
                        },
                        "responses": {
                          "keypress": "doublepress"
                        },
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Reward",
                        "timeout": "400",
                        "tardy": true,
                        "skip": "${ z == 1 || y == 0 || q == 1 || ( highrew == 1 && r \u003E= rewprob) || (highrew == 0 && r \u003E= (1-rewprob)) }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": "#ffffff",
                            "strokeWidth": 1,
                            "fill": "#000000"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 464.26,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Please only press one key at a time.",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -112,
                            "angle": 0,
                            "width": 710.55,
                            "height": 78.11,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'skipped' ? l = 1 : l = 0 }\n${ state.ended_on == 'timeout' ? this.parameters.p[0]++ : this.parameters.p[0] = this.parameters.p[0] }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": 32,
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Doppelter Tastendruck",
                        "skip": "${ state.ended_on != 'response' }",
                        "tardy": true,
                        "timeout": "1200"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"smiley_small_green.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "1eurocoin.png": "embedded\u002F7f759ca75bdc64bef84579d85e9384c3c4059b4aa80415ebd58b8b2e5defb010.png",
                          "smiley_small_green.png": "embedded\u002F461ff38348b0701b6add328b041b0d329602f61238f1427d5a0575b0536093d8.png"
                        },
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "ITI rew",
                        "timeout": "100",
                        "tardy": true,
                        "skip": "${ l == 1 || state.ended_on == 'timeout' }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x }",
                            "top": "${ parameters.position_y }",
                            "angle": 0,
                            "width": "50",
                            "height": 19.2,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x2 }",
                            "top": "${ parameters.position_y2 }",
                            "angle": 0,
                            "width": "50",
                            "height": 28.87,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"frowny_small_red.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png",
                          "frowny_small_red.png": "embedded\u002F75fcaf37aa5bd8004458100177b49f7d494b504f1fe5c8468fad8d2e53937f64.png"
                        },
                        "responses": {
                          "keypress": "doublepress"
                        },
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "White Point",
                        "timeout": "400",
                        "tardy": true,
                        "skip": "${ z == 1 || y == 0 || q == 1 || (highrew == 1 && r \u003C rewprob) || (highrew == 0 && r \u003C (1-rewprob)) }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": "#ffffff",
                            "strokeWidth": 1,
                            "fill": "#000000"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 464.27,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Please only press one key at a time.",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -115,
                            "angle": 0,
                            "width": 640.27,
                            "height": 36.16,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'skipped' ? l = 1 : l = 0 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": 32,
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Doppelter Tastendruck",
                        "skip": "${ state.ended_on != 'response' }",
                        "tardy": true,
                        "timeout": "1200"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": 0,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"frowny_small_red.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "eurocoin.png": "embedded\u002F9900964815a8e0cd3720da6b02e876ef60c7ced319b0eda68df95478d4066e0a.png",
                          "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                          "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png",
                          "frowny_small_red.png": "embedded\u002F75fcaf37aa5bd8004458100177b49f7d494b504f1fe5c8468fad8d2e53937f64.png"
                        },
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "ITI norew",
                        "timeout": "100",
                        "tardy": true,
                        "skip": "${ l == 1 || state.ended_on == 'timeout' }"
                      }
                    ]
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "rect",
                        "left": 150,
                        "top": 63,
                        "angle": 0,
                        "width": 1582.18,
                        "height": 810.26,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black"
                      },
                      {
                        "type": "i-text",
                        "left": 0,
                        "top": 0,
                        "angle": 0,
                        "width": 304.91,
                        "height": 27.12,
                        "stroke": "#ffffff",
                        "strokeWidth": 0,
                        "fill": "#ffffff",
                        "text": "",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": "24",
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {},
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "total errors",
                    "tardy": true,
                    "skip": true
                  },
                  {
                    "type": "lab.flow.Sequence",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "Zu viele Fehler",
                    "tardy": true,
                    "skip": "${ x \u003C 5 }",
                    "content": [
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -25,
                            "angle": 0,
                            "width": 536.34,
                            "height": 58.58,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "You've made too many errors in a row.\n\nTheexperiment will continue in a few seconds.",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Zu viele Fehler",
                        "timeout": "3000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 15.57,
                            "height": 31.64,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "3",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "28",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Instruction_Countdown",
                        "timeout": "1000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 15.57,
                            "height": 31.64,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "2",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "28",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Instruction_Countdown",
                        "timeout": "1000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 15.57,
                            "height": 31.64,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "1",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "28",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Instruction_Countdown",
                        "timeout": "1000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 15.57,
                            "height": 31.64,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "0",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "28",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Instruction_Countdown",
                        "timeout": "1000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 150,
                            "top": 63,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 492.19,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "${ state.ended_on == 'skipped' ? x = x : x = 0 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Addition",
                        "timeout": "1000",
                        "tardy": true,
                        "skip": true
                      }
                    ]
                  }
                ]
              }
            },
            {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Instruction_Trials",
              "skip": true,
              "content": [
                {
                  "type": "lab.flow.Loop",
                  "templateParameters": [
                    {
                      "position_x": "95",
                      "position_y": "-36"
                    },
                    {
                      "position_x": "95",
                      "position_y": "36"
                    },
                    {
                      "position_x": "95",
                      "position_y": "36"
                    },
                    {
                      "position_x": "95",
                      "position_y": "36"
                    },
                    {
                      "position_x": "-95",
                      "position_y": "-36"
                    },
                    {
                      "position_x": "95",
                      "position_y": "-36"
                    },
                    {
                      "position_x": "-95",
                      "position_y": "36"
                    },
                    {
                      "position_x": "95",
                      "position_y": "-36"
                    },
                    {
                      "position_x": "95",
                      "position_y": "-36"
                    },
                    {
                      "position_x": "-95",
                      "position_y": "-36"
                    },
                    {
                      "position_x": "-95",
                      "position_y": "36"
                    },
                    {
                      "position_x": "95",
                      "position_y": "-36"
                    },
                    {
                      "position_x": "95",
                      "position_y": "36"
                    },
                    {
                      "position_x": "95",
                      "position_y": "36"
                    },
                    {
                      "position_x": "95",
                      "position_y": "36"
                    }
                  ],
                  "sample": {
                    "mode": "sequential",
                    "n": ""
                  },
                  "files": {
                    "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                    "no1eurocoin.png": "embedded\u002F95d63f46dcb769bd416c2cc782f5c6def0fbeb89d3740e3196c6a5ae06e4553a.png",
                    "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png"
                  },
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {
                    "run": function anonymous(
) {
x = 0
z = 0 
highrew = 0
}
                  },
                  "title": "Instruction_Trials",
                  "shuffleGroups": [],
                  "template": {
                    "type": "lab.flow.Sequence",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "Trials",
                    "content": [
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 2009.1,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": -12,
                            "top": 0,
                            "angle": 0,
                            "width": 877.45,
                            "height": 121.5,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "${ z == 1 || i  == 1 ? k = 800 : k = 600 }\n${ r = Math.random() }\n${ (parameters.position_x == '95' && parameters.position_y == '36')||\n(parameters.position_x == '-95' && parameters.position_y == '-36') ? highrew = 0 : highrew = 1 } ",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "random number",
                        "tardy": true,
                        "skip": true
                      },
                      {
                        "type": "lab.flow.Sequence",
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Single",
                        "tardy": true,
                        "content": [
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "image",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": "10000",
                                "height": "10000",
                                "stroke": null,
                                "strokeWidth": 0,
                                "fill": "black",
                                "src": "${ this.files[\"Background.PNG\"] }"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "circle",
                                "left": "${ parameters.position_x }",
                                "top": "${ parameters.position_y }",
                                "angle": 0,
                                "width": 50,
                                "height": 50,
                                "stroke": "#00aa00",
                                "strokeWidth": 1,
                                "fill": "#00aa00"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {
                              "Background.PNG": "embedded\u002Ff6e74e440a74dbed53dbea3dfe3e6d9e7676ed25544b5f21e65d1ba6576cd36c.PNG"
                            },
                            "responses": {
                              "keypress(s)": "-95 -36",
                              "keypress(x)": "-95 36",
                              "keypress(k)": "95 -36",
                              "keypress(m)": "95 36",
                              "keypress(S)": "-95 -36",
                              "keypress(X)": "-95 36",
                              "keypress(K)": "95 -36",
                              "keypress(M)": "95 36"
                            },
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Stimulus",
                            "timeout": "${k}",
                            "correctResponse": "${ parameters.position_x } ${ parameters.position_y }",
                            "tardy": true
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": 136,
                                "top": -25,
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": "#ffffff",
                                "strokeWidth": 1,
                                "fill": "#000000"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 141.69,
                                "height": 27.12,
                                "stroke": "#ffffff",
                                "strokeWidth": 0,
                                "fill": "#ffffff",
                                "text": "Too slow",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": "24",
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": -175,
                                "angle": 0,
                                "width": 1156.86,
                                "height": 78.11,
                                "stroke": "#000000",
                                "strokeWidth": 1,
                                "fill": "#000000",
                                "text": "${ state.ended_on  == 'response' && state.correct ? x = 0 : x = x + 1 }",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": 32,
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {},
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Zu Schnell\u002Flangsam",
                            "skip": "${ state.ended_on !== 'timeout' }",
                            "tardy": true,
                            "timeout": "1200"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": 150,
                                "top": 63,
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": "#000000",
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 489.51,
                                "height": 27.12,
                                "stroke": "#ffffff",
                                "strokeWidth": 0,
                                "fill": "#ffffff",
                                "text": "${ state.ended_on == 'timeout' ? z = 1 : z = 0 }",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": "24",
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {},
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Addition",
                            "tardy": true,
                            "skip": true
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": 125,
                                "top": -25,
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 154.74,
                                "height": 27.12,
                                "stroke": "#ffffff",
                                "strokeWidth": 0,
                                "fill": "#ffffff",
                                "text": "Wrong key!",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": "24",
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {
                              "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                              "no1eurocoin.png": "embedded\u002F95d63f46dcb769bd416c2cc782f5c6def0fbeb89d3740e3196c6a5ae06e4553a.png",
                              "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png"
                            },
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "no reward",
                            "timeout": "1200",
                            "tardy": true,
                            "skip": "${ z == 1 || state.correct }"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": 125,
                                "top": -25,
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "circle",
                                "left": "${ parameters.position_x }",
                                "top": "${ parameters.position_y }",
                                "angle": 0,
                                "width": 50,
                                "height": 50,
                                "stroke": "#00aa00",
                                "strokeWidth": 1,
                                "fill": "#00aa00"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": -150,
                                "angle": 0,
                                "width": 634.91,
                                "height": 36.16,
                                "stroke": "#000000",
                                "strokeWidth": 1,
                                "fill": "#000000",
                                "text": "${ state.ended_on == 'timeout' ? i = 1 : i = 0 }",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": 32,
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              },
                              {
                                "type": "image",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 63.77,
                                "height": 64.12,
                                "stroke": null,
                                "strokeWidth": 0,
                                "fill": "black",
                                "src": "${ this.files[\"1eurocoin.png\"] }"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {
                              "1eurocoin.png": "embedded\u002F7f759ca75bdc64bef84579d85e9384c3c4059b4aa80415ebd58b8b2e5defb010.png"
                            },
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Reward",
                            "timeout": "400",
                            "tardy": true,
                            "skip": "${ z == 1 || (state.correct == 1) == 0 || (highrew == 0 && r \u003E= rewprob) || (highrew == 1 && r \u003C rewprob)}"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": 125,
                                "top": -25,
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "image",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 63.77,
                                "height": 64.12,
                                "stroke": null,
                                "strokeWidth": 0,
                                "fill": "black",
                                "src": "${ this.files[\"1eurocoin.png\"] }"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {
                              "1eurocoin.png": "embedded\u002F7f759ca75bdc64bef84579d85e9384c3c4059b4aa80415ebd58b8b2e5defb010.png"
                            },
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "ITI",
                            "timeout": "100",
                            "tardy": true,
                            "skip": "${state.ended_on == 'skipped'}"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": "125",
                                "top": "-25",
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "circle",
                                "left": "${ parameters.position_x }",
                                "top": "${ parameters.position_y }",
                                "angle": 0,
                                "width": "50",
                                "height": 19.2,
                                "stroke": "#00aa00",
                                "strokeWidth": 1,
                                "fill": "#00aa00"
                              },
                              {
                                "type": "image",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": "45",
                                "height": "45",
                                "stroke": null,
                                "strokeWidth": 0,
                                "fill": "black",
                                "src": "${ this.files[\"whitepoint.png\"] }"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {
                              "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png"
                            },
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "White Point",
                            "timeout": "400",
                            "tardy": true,
                            "skip": "${ z == 1 || (state.correct == 1) == 0 || (highrew == 0 && r \u003C rewprob) || (highrew == 1 && r \u003E rewprob)}"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": 125,
                                "top": -25,
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "image",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": "45",
                                "height": "45",
                                "stroke": null,
                                "strokeWidth": 0,
                                "fill": "black",
                                "src": "${ this.files[\"whitepoint.png\"] }"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {
                              "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                              "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png"
                            },
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "ITI",
                            "timeout": "100",
                            "tardy": true,
                            "skip": "${ state.ended_on == 'skipped'}"
                          }
                        ]
                      },
                      {
                        "type": "lab.flow.Sequence",
                        "files": {},
                        "responses": {
                          "": ""
                        },
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Zu viele Fehler",
                        "tardy": true,
                        "skip": "${ x \u003C 5 }",
                        "content": [
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": 125,
                                "top": -25,
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": -25,
                                "angle": 0,
                                "width": 536.34,
                                "height": 58.58,
                                "stroke": "#ffffff",
                                "strokeWidth": 0,
                                "fill": "#ffffff",
                                "text": "You've made too many errors in a row.\n\nTheexperiment will continue in a few seconds.",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": "24",
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {},
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Zu viele Fehler",
                            "timeout": "3000"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": "125",
                                "top": "-25",
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 15.57,
                                "height": 31.64,
                                "stroke": null,
                                "strokeWidth": 0,
                                "fill": "#ffffff",
                                "text": "3",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": "28",
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {},
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Instruction_Countdown",
                            "timeout": "1000"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": "125",
                                "top": "-25",
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 15.57,
                                "height": 31.64,
                                "stroke": null,
                                "strokeWidth": 0,
                                "fill": "#ffffff",
                                "text": "2",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": "28",
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {},
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Instruction_Countdown",
                            "timeout": "1000"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": "125",
                                "top": "-25",
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 15.57,
                                "height": 31.64,
                                "stroke": null,
                                "strokeWidth": 0,
                                "fill": "#ffffff",
                                "text": "1",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": "28",
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {},
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Instruction_Countdown",
                            "timeout": "1000"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": "125",
                                "top": "-25",
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 15.57,
                                "height": 31.64,
                                "stroke": null,
                                "strokeWidth": 0,
                                "fill": "#ffffff",
                                "text": "0",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": "28",
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {},
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Instruction_Countdown",
                            "timeout": "1000"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": 150,
                                "top": 63,
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 492.19,
                                "height": 27.12,
                                "stroke": "#ffffff",
                                "strokeWidth": 0,
                                "fill": "#ffffff",
                                "text": "${ state.ended_on == 'skipped' ? x = x : x = 0 }",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": "24",
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {},
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Addition",
                            "timeout": "1000",
                            "tardy": true,
                            "skip": true
                          }
                        ]
                      }
                    ]
                  }
                },
                {
                  "type": "lab.flow.Loop",
                  "templateParameters": [
                    {
                      "position_x": "-95",
                      "position_y": "-36"
                    },
                    {
                      "position_x": "-95",
                      "position_y": "-36"
                    },
                    {
                      "position_x": "95",
                      "position_y": "36"
                    },
                    {
                      "position_x": "-95",
                      "position_y": "-36"
                    },
                    {
                      "position_x": "-95",
                      "position_y": "36"
                    },
                    {
                      "position_x": "95",
                      "position_y": "36"
                    },
                    {
                      "position_x": "95",
                      "position_y": "36"
                    },
                    {
                      "position_x": "95",
                      "position_y": "-36"
                    },
                    {
                      "position_x": "-95",
                      "position_y": "-36"
                    },
                    {
                      "position_x": "95",
                      "position_y": "36"
                    },
                    {
                      "position_x": "95",
                      "position_y": "-36"
                    },
                    {
                      "position_x": "-95",
                      "position_y": "-36"
                    },
                    {
                      "position_x": "-95",
                      "position_y": "-36"
                    },
                    {
                      "position_x": "-95",
                      "position_y": "36"
                    },
                    {
                      "position_x": "95",
                      "position_y": "36"
                    }
                  ],
                  "sample": {
                    "mode": "sequential",
                    "n": ""
                  },
                  "files": {
                    "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                    "no1eurocoin.png": "embedded\u002F95d63f46dcb769bd416c2cc782f5c6def0fbeb89d3740e3196c6a5ae06e4553a.png",
                    "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png"
                  },
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {
                    "run": function anonymous(
) {
x = 0
z = 0 
highrew = 0
}
                  },
                  "title": "Instruction_Trials 2",
                  "shuffleGroups": [],
                  "template": {
                    "type": "lab.flow.Sequence",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "Trials",
                    "content": [
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 2009.1,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": -14,
                            "top": 0,
                            "angle": 0,
                            "width": 877.45,
                            "height": 121.5,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "${ z == 1 || i  == 1 ? k = 800 : k = 600 }\n${ r = Math.random() }\n${ (parameters.position_x == '95' && parameters.position_y == '36')||\n(parameters.position_x == '-95' && parameters.position_y == '-36') ? highrew = 0 : highrew = 1 } ",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "random number",
                        "tardy": true,
                        "skip": true
                      },
                      {
                        "type": "lab.flow.Sequence",
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Single",
                        "tardy": true,
                        "content": [
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "image",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": "10000",
                                "height": "10000",
                                "stroke": null,
                                "strokeWidth": 0,
                                "fill": "black",
                                "src": "${ this.files[\"Background.PNG\"] }"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "circle",
                                "left": "${ parameters.position_x }",
                                "top": "${ parameters.position_y }",
                                "angle": 0,
                                "width": 50,
                                "height": 50,
                                "stroke": "#00aa00",
                                "strokeWidth": 1,
                                "fill": "#00aa00"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {
                              "Background.PNG": "embedded\u002Ff6e74e440a74dbed53dbea3dfe3e6d9e7676ed25544b5f21e65d1ba6576cd36c.PNG"
                            },
                            "responses": {
                              "keypress(s)": "-95 -36",
                              "keypress(x)": "-95 36",
                              "keypress(k)": "95 -36",
                              "keypress(m)": "95 36",
                              "keypress(S)": "-95 -36",
                              "keypress(X)": "-95 36",
                              "keypress(K)": "95 -36",
                              "keypress(M)": "95 36"
                            },
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Stimulus",
                            "timeout": "${k}",
                            "correctResponse": "${ parameters.position_x } ${ parameters.position_y }",
                            "tardy": true
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": 136,
                                "top": -25,
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": "#ffffff",
                                "strokeWidth": 1,
                                "fill": "#000000"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 125.39,
                                "height": 27.12,
                                "stroke": "#ffffff",
                                "strokeWidth": 0,
                                "fill": "#ffffff",
                                "text": "Too slow",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": "24",
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": -175,
                                "angle": 0,
                                "width": 977.28,
                                "height": 36.16,
                                "stroke": "#000000",
                                "strokeWidth": 1,
                                "fill": "#000000",
                                "text": "${ state.ended_on  == 'response' && state.correct ? x = 0 : x = x + 1 }",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": 32,
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {},
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Zu Schnell\u002Flangsam",
                            "skip": "${ state.ended_on !== 'timeout' }",
                            "tardy": true,
                            "timeout": "1200"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": 150,
                                "top": 63,
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": "#000000",
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 489.51,
                                "height": 27.12,
                                "stroke": "#ffffff",
                                "strokeWidth": 0,
                                "fill": "#ffffff",
                                "text": "${ state.ended_on == 'timeout' ? z = 1 : z = 0 }",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": "24",
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {},
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Addition",
                            "tardy": true,
                            "skip": true
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": 125,
                                "top": -25,
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 154.74,
                                "height": 27.12,
                                "stroke": "#ffffff",
                                "strokeWidth": 0,
                                "fill": "#ffffff",
                                "text": "Wrong key!",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": "24",
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {
                              "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                              "no1eurocoin.png": "embedded\u002F95d63f46dcb769bd416c2cc782f5c6def0fbeb89d3740e3196c6a5ae06e4553a.png",
                              "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png"
                            },
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "no reward",
                            "timeout": "1200",
                            "tardy": true,
                            "skip": "${ z == 1 || state.correct }"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": 125,
                                "top": -25,
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "circle",
                                "left": "${ parameters.position_x }",
                                "top": "${ parameters.position_y }",
                                "angle": 0,
                                "width": 50,
                                "height": 50,
                                "stroke": "#00aa00",
                                "strokeWidth": 1,
                                "fill": "#00aa00"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": -150,
                                "angle": 0,
                                "width": 634.91,
                                "height": 36.16,
                                "stroke": "#000000",
                                "strokeWidth": 1,
                                "fill": "#000000",
                                "text": "${ state.ended_on == 'timeout' ? i = 1 : i = 0 }",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": 32,
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              },
                              {
                                "type": "image",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 63.77,
                                "height": 64.12,
                                "stroke": null,
                                "strokeWidth": 0,
                                "fill": "black",
                                "src": "${ this.files[\"1eurocoin.png\"] }"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {
                              "1eurocoin.png": "embedded\u002F7f759ca75bdc64bef84579d85e9384c3c4059b4aa80415ebd58b8b2e5defb010.png"
                            },
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Reward",
                            "timeout": "400",
                            "tardy": true,
                            "skip": "${ z == 1 || (state.correct == 1) == 0 || (highrew == 0 && r \u003E= rewprob) || (highrew == 1 && r \u003C= rewprob)}"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": 125,
                                "top": -25,
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "image",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 63.77,
                                "height": 64.12,
                                "stroke": null,
                                "strokeWidth": 0,
                                "fill": "black",
                                "src": "${ this.files[\"1eurocoin.png\"] }"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {
                              "1eurocoin.png": "embedded\u002F7f759ca75bdc64bef84579d85e9384c3c4059b4aa80415ebd58b8b2e5defb010.png"
                            },
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "ITI",
                            "timeout": "100",
                            "tardy": true,
                            "skip": "${state.ended_on == 'skipped'}"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": "125",
                                "top": "-25",
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "circle",
                                "left": "${ parameters.position_x }",
                                "top": "${ parameters.position_y }",
                                "angle": 0,
                                "width": "50",
                                "height": 19.2,
                                "stroke": "#00aa00",
                                "strokeWidth": 1,
                                "fill": "#00aa00"
                              },
                              {
                                "type": "image",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": "45",
                                "height": "45",
                                "stroke": null,
                                "strokeWidth": 0,
                                "fill": "black",
                                "src": "${ this.files[\"whitepoint.png\"] }"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {
                              "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png"
                            },
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "White Point",
                            "timeout": "400",
                            "tardy": true,
                            "skip": "${ z == 1 || (state.correct == 1) == 0 || (highrew == 0 && r \u003C rewprob) || (highrew == 1 && r \u003E rewprob)}"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": 125,
                                "top": -25,
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "image",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": "45",
                                "height": "45",
                                "stroke": null,
                                "strokeWidth": 0,
                                "fill": "black",
                                "src": "${ this.files[\"whitepoint.png\"] }"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {
                              "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                              "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png"
                            },
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "ITI",
                            "timeout": "100",
                            "tardy": true,
                            "skip": "${ state.ended_on == 'skipped'}"
                          }
                        ]
                      },
                      {
                        "type": "lab.flow.Sequence",
                        "files": {},
                        "responses": {
                          "": ""
                        },
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Zu viele Fehler",
                        "tardy": true,
                        "skip": "${ x \u003C 5 }",
                        "content": [
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": 125,
                                "top": -25,
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": -25,
                                "angle": 0,
                                "width": 536.34,
                                "height": 58.58,
                                "stroke": "#ffffff",
                                "strokeWidth": 0,
                                "fill": "#ffffff",
                                "text": "You've made too many errors in a row.\n\nTheexperiment will continue in a few seconds.",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": "24",
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {},
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Zu viele Fehler",
                            "timeout": "3000"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": "125",
                                "top": "-25",
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 15.57,
                                "height": 31.64,
                                "stroke": null,
                                "strokeWidth": 0,
                                "fill": "#ffffff",
                                "text": "3",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": "28",
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {},
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Instruction_Countdown",
                            "timeout": "1000"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": "125",
                                "top": "-25",
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 15.57,
                                "height": 31.64,
                                "stroke": null,
                                "strokeWidth": 0,
                                "fill": "#ffffff",
                                "text": "2",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": "28",
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {},
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Instruction_Countdown",
                            "timeout": "1000"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": "125",
                                "top": "-25",
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 15.57,
                                "height": 31.64,
                                "stroke": null,
                                "strokeWidth": 0,
                                "fill": "#ffffff",
                                "text": "1",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": "28",
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {},
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Instruction_Countdown",
                            "timeout": "1000"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": "125",
                                "top": "-25",
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": -36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": -95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "rect",
                                "left": 95,
                                "top": 36,
                                "angle": 0,
                                "width": 70,
                                "height": 70,
                                "stroke": "#ffffff",
                                "strokeWidth": 2,
                                "fill": "black"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 15.57,
                                "height": 31.64,
                                "stroke": null,
                                "strokeWidth": 0,
                                "fill": "#ffffff",
                                "text": "0",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": "28",
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {},
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Instruction_Countdown",
                            "timeout": "1000"
                          },
                          {
                            "type": "lab.canvas.Screen",
                            "content": [
                              {
                                "type": "rect",
                                "left": 150,
                                "top": 63,
                                "angle": 0,
                                "width": 1582.18,
                                "height": 810.26,
                                "stroke": null,
                                "strokeWidth": 1,
                                "fill": "black"
                              },
                              {
                                "type": "i-text",
                                "left": 0,
                                "top": 0,
                                "angle": 0,
                                "width": 492.19,
                                "height": 27.12,
                                "stroke": "#ffffff",
                                "strokeWidth": 0,
                                "fill": "#ffffff",
                                "text": "${ state.ended_on == 'skipped' ? x = x : x = 0 }",
                                "fontStyle": "normal",
                                "fontWeight": "normal",
                                "fontSize": "24",
                                "fontFamily": "sans-serif",
                                "lineHeight": 1.16,
                                "textAlign": "center"
                              }
                            ],
                            "viewport": [
                              800,
                              600
                            ],
                            "files": {},
                            "responses": {},
                            "parameters": {},
                            "messageHandlers": {},
                            "title": "Addition",
                            "timeout": "1000",
                            "tardy": true,
                            "skip": true
                          }
                        ]
                      }
                    ]
                  }
                }
              ]
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "rect",
                  "left": 125,
                  "top": -25,
                  "angle": 0,
                  "width": 1582.18,
                  "height": 810.26,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": -100,
                  "angle": 0,
                  "width": 662.69,
                  "height": 90.04,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "That's it for the instructions!\n\nWhen you are ready, press any key to start the experiment.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {},
              "parameters": {},
              "messageHandlers": {},
              "title": "Instruction_end",
              "timeout": "1000"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "rect",
                  "left": 125,
                  "top": -25,
                  "angle": 0,
                  "width": 1582.18,
                  "height": 810.26,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": -100,
                  "angle": 0,
                  "width": 662.69,
                  "height": 90.04,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "That's it for the instructions!\n\nWhen you are ready, press any key to start the experiment.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Instruction_end"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "rect",
                  "left": 125,
                  "top": -25,
                  "angle": 0,
                  "width": 1582.18,
                  "height": 810.26,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": -100,
                  "angle": 0,
                  "width": 401.04,
                  "height": 27.12,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "Experiment will start momentarily...",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {},
              "parameters": {},
              "messageHandlers": {},
              "title": "Gleich gehts los",
              "timeout": "3000"
            }
          ]
        }
      ]
    }
  ]
})

// Let's go!
study.run()