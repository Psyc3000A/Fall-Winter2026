// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    },
    {
      "type": "lab.plugins.Transmit",
      "url": "\u002Fsave",
      "encoding": "form",
      "updates": {
        "incremental": false
      },
      "callbacks": {
        "setup": function(){this.headers["X-CSRFToken"]=window.csrf_token},
        "full": function(e){e&&e.ok&&(window.location="/next")}
      },
      "path": undefined
    }
  ],
  "metadata": {
    "title": "",
    "description": "",
    "repository": "",
    "contributors": ""
  },
  "messageHandlers": {},
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.flow.Sequence",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "run": function anonymous(
) {
rewprob = 0.8 // rew prob for TOP LEFT and BOTTOM RIGHT
hr_tl_br = 1 // HighRew (hr) is top left (tl) and bottom right (br)
x = 0
z = 0 // Error Variable Timeout
highrew = 0 // 1 if sequence stimulus is high reward prob, 0 otherwise, defined @ "random number", or "Abfrage 2ter Tastendruck" for Joker Trials
i = 0 // 1 if person corrected incorrectly
this.parameters.p = Array([0]) // no. of points received
e = 0
h = 0
n = 0
q = 0
o = 0 // o = 1 if criterion test is passed
q_false = 0 // test questions wrongly answered?
}
      },
      "title": "Grp1 Day1:1",
      "content": [
        {
          "type": "lab.flow.Sequence",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "Instruction",
          "content": [
            {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Description",
              "content": [
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -25,
                      "angle": 0,
                      "width": 441.48,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Hello and thank you for your participation!",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -25,
                      "angle": 0,
                      "width": 342.67,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Please press F11 for full screen.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction F11"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -25,
                      "angle": 0,
                      "width": 664.49,
                      "height": 58.58,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Please eliminate all possible sources of distraction \n(including your phone), and refrain from listening to music.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 464.24,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction Störquellen"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -25,
                      "angle": 0,
                      "width": 584.4,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Today's experiment will take around 75 minutes in total.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction: Dauer"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -25,
                      "angle": 0,
                      "width": 540.24,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "In the following your task will be explained in detail.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -140,
                      "angle": 0,
                      "width": 442.75,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "In the center of the screen are four boxes:",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -140,
                      "angle": 0,
                      "width": 577.18,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "In these boxes, circles will appear in quick succession.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "circle",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 50,
                      "height": 50,
                      "stroke": "#00aa00",
                      "strokeWidth": 1,
                      "fill": "#00aa00"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -211,
                      "angle": 0,
                      "width": 575.81,
                      "height": 58.58,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "You will then have a certain amount of time to respond\nby pressing the corresponding key on the keyboard.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 526.14,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 20.31,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#ffffff",
                      "text": "S",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 21.92,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#ffffff",
                      "text": "X",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 20.98,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#ffffff",
                      "text": "K",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 27.61,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#ffffff",
                      "text": "M",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 250,
                      "top": -100,
                      "angle": 0,
                      "width": 106.56,
                      "height": 27.12,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#ffffff",
                      "text": "right hand",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": -250,
                      "top": -100,
                      "angle": 0,
                      "width": 92.38,
                      "height": 27.12,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "left hand",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": -250,
                      "top": -36,
                      "angle": 0,
                      "width": 137.26,
                      "height": 27.12,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "middle finger",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": -250,
                      "top": 36,
                      "angle": 0,
                      "width": 123.24,
                      "height": 27.12,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "index finger",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 250,
                      "top": -36,
                      "angle": 0,
                      "width": 137.26,
                      "height": 27.12,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "middle finger",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 250,
                      "top": 36,
                      "angle": 0,
                      "width": 123.24,
                      "height": 27.12,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "index finger",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction: Tastenbelegung"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -125,
                      "angle": 0,
                      "width": 634.61,
                      "height": 58.58,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "If the correct key was pressed within the allotted timeframe, \nthere are two posiibilities.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction: Zwei Möglichkeiten"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -175,
                      "angle": 0,
                      "width": 721.56,
                      "height": 184.42,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "With a certain probability you receive a point.\nIn this case, a smiley face will appear in the center of the screen.\n\n\n\n",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 316.9,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "image",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 53.28,
                      "height": 51.54,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"smiley_small_green.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "1eurocoin.png": "embedded\u002F7f759ca75bdc64bef84579d85e9384c3c4059b4aa80415ebd58b8b2e5defb010.png",
                    "smiley_small_green.png": "embedded\u002F461ff38348b0701b6add328b041b0d329602f61238f1427d5a0575b0536093d8.png"
                  },
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction: Münze"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -175,
                      "angle": 0,
                      "width": 721.56,
                      "height": 184.42,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "With a certain probability you receive a point.\nIn this case, a smiley face will appear in the center of the screen.\nYour points are counted in the background.\n\n\n",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 316.9,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "image",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 53.28,
                      "height": 51.54,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"smiley_small_green.png\"] }"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -135,
                      "angle": 0,
                      "width": 778.73,
                      "height": 58.58,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#d6341a",
                      "text": "The more points you collect, the higher your bonus payout at the\nend of the experiment will be.",
                      "fontStyle": "normal",
                      "fontWeight": "bold",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "1eurocoin.png": "embedded\u002F7f759ca75bdc64bef84579d85e9384c3c4059b4aa80415ebd58b8b2e5defb010.png",
                    "smiley_small_green.png": "embedded\u002F461ff38348b0701b6add328b041b0d329602f61238f1427d5a0575b0536093d8.png"
                  },
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction: Münze"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -186,
                      "angle": 0,
                      "width": 784.32,
                      "height": 58.58,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "There's a chance you don't win a point, even after pressing the\ncorrect key. In this case, a sad face will appear in the center of the screen.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 464.24,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "image",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": "50",
                      "height": "49",
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"frowny_small_red.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png",
                    "frowny_small_red.png": "embedded\u002F75fcaf37aa5bd8004458100177b49f7d494b504f1fe5c8468fad8d2e53937f64.png"
                  },
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction white dot"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -150,
                      "angle": 0,
                      "width": 588.58,
                      "height": 58.58,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "If you don't react within the given timeframe, this screen\nwill appear for about a second:",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 464.24,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 99.48,
                      "height": 27.12,
                      "stroke": "#000000",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Too slow!",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "no1eurocoin.png": "embedded\u002F95d63f46dcb769bd416c2cc782f5c6def0fbeb89d3740e3196c6a5ae06e4553a.png"
                  },
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction zu langsam",
                  "skip": true
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": 0,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -125,
                      "angle": 0,
                      "width": 664.22,
                      "height": 58.58,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "It is your task to collect as many points as possible throughout \nthe experiment.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "no1eurocoin.png": "embedded\u002F95d63f46dcb769bd416c2cc782f5c6def0fbeb89d3740e3196c6a5ae06e4553a.png"
                  },
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction Punkte sammeln"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -75,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -200,
                      "angle": 0,
                      "width": 781.61,
                      "height": 90.04,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "The probability of winning a point upon a correct response is not the same\nin every box. The green boxes have a higher probability of \nwinning a point than the red ones.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -90,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -89,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                    "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
                  },
                  "responses": {
                    "keypress": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Feedback Reward Probs 1",
                  "tardy": true,
                  "skip": "${hr_tl_br == 0}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -75,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -200,
                      "angle": 0,
                      "width": 781.61,
                      "height": 90.04,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "The probability of winning a point upon a correct keypress is not the same\nin every box. The green boxes have a higher probability of \nwinning a point than the red ones.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 464.24,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": "95",
                      "top": "-36",
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "image",
                      "left": "100",
                      "top": "-37",
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": "-90",
                      "top": "37",
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": "-90",
                      "top": "-37",
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": "100",
                      "top": "37",
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                    "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
                  },
                  "responses": {
                    "keypress": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Feedback Reward Probs 2",
                  "tardy": true,
                  "skip": "${hr_tl_br == 1}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -75,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -200,
                      "angle": 0,
                      "width": 529.08,
                      "height": 58.58,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Throughout the experiment the chances for each box of winning a point do not change.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -90,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -89,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                    "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
                  },
                  "responses": {
                    "keypress": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Feedback Reward Probs 1",
                  "tardy": true,
                  "skip": "${hr_tl_br == 0}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -75,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -200,
                      "angle": 0,
                      "width": 529.08,
                      "height": 58.58,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "The win probabilities of the boxes do NOT change\nduring the experiment.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -90,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -90,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                    "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
                  },
                  "responses": {
                    "keypress": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Feedback Reward Probs 2",
                  "tardy": true,
                  "skip": "${hr_tl_br == 1}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -175,
                      "angle": 0,
                      "width": 782.9,
                      "height": 90.04,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Sometimes, two circles will appear at the same time. \nIn this case, you should press only one of the two corresponding keys. \nWhich one you press is up to you.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 464.24,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "circle",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 50,
                      "height": 50,
                      "stroke": "#00aa00",
                      "strokeWidth": 1,
                      "fill": "#00aa00"
                    },
                    {
                      "type": "circle",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 50,
                      "height": 50,
                      "stroke": "#00aa00",
                      "strokeWidth": 1,
                      "fill": "#00aa00"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction Joker"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -175,
                      "angle": 0,
                      "width": 543.43,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "You should NOT press both keys at the same time. ",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "black"
                    },
                    {
                      "type": "circle",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 50,
                      "height": 50,
                      "stroke": "#00aa00",
                      "strokeWidth": 1,
                      "fill": "#00aa00"
                    },
                    {
                      "type": "circle",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 50,
                      "height": 50,
                      "stroke": "#00aa00",
                      "strokeWidth": 1,
                      "fill": "#00aa00"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction Joker",
                  "skip": true
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -150,
                      "angle": 0,
                      "width": 751.46,
                      "height": 58.58,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "If you press two keys at the same time, \nyou do not receive a point, and this screen will appear for two seconds:",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 382.51,
                      "height": 27.12,
                      "stroke": "#000000",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Please only press one key at a time.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "no1eurocoin.png": "embedded\u002F95d63f46dcb769bd416c2cc782f5c6def0fbeb89d3740e3196c6a5ae06e4553a.png"
                  },
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -100,
                      "angle": 0,
                      "width": 865.88,
                      "height": 184.42,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Im Folgenden werden Ihnen zur Verständnisüberprüfung ein paar Fragen gestellt.\nBei jeder Frage gibt es genau EINE korrekte Antwort.\n\n\n \n",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 464.24,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction",
                  "skip": true
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -100,
                      "angle": 0,
                      "width": 865.88,
                      "height": 184.42,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Im Folgenden werden Ihnen zur Verständnisüberprüfung ein paar Fragen gestellt.\nBei jeder Frage gibt es genau EINE korrekte Antwort.\n\n\nZur Beantwortung wählen Sie die korrekte Antwort mit der Maus aus \nund drücken Sie anschließend auf die Schaltfläche 'Weiter'.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 464.24,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction",
                  "skip": true
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": 0,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -100,
                      "angle": 0,
                      "width": 574.32,
                      "height": 121.5,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "You will frequently have the chance to take breaks.\nUse those breaks to take a breath and relax.\nYou can pause as long as you like, however please try\nnot to pause for longer than 3 minutes.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 463.08,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "no1eurocoin.png": "embedded\u002F95d63f46dcb769bd416c2cc782f5c6def0fbeb89d3740e3196c6a5ae06e4553a.png"
                  },
                  "responses": {
                    "keypress(Space)": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction Pausen"
                }
              ]
            }
          ]
        },
        {
          "type": "lab.flow.Sequence",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "Test-Questions ",
          "skip": true,
          "content": [
            {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Question 1: Feedback Korrekte Reaktion",
              "content": [
                {
                  "type": "lab.html.Form",
                  "content": "\u003Cmain\u003E\n  \u003Cform\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cp\u003EWas passiert bei einer korrekten Reaktion?\u003C\u002Fp\u003E\n    \u003Cinput type=\"radio\" name=\"Frage1\" value=\"a\"\u003E Es erscheint eine Euromünze und Sie erhalten einen Punkt.\u003Cbr\u003E\n    \u003Cinput type=\"radio\" name=\"Frage1\" value=\"b\"\u003E Es erscheint entweder eine Euromünze und Sie erhalten einen Punkt oder es erscheint ein weißer Kreis und Sie erhalten keinen Punkt.\u003Cbr\u003E\n    \u003Cinput type=\"radio\" name=\"Frage1\" value=\"c\"\u003E Es erscheint ein weißer Kreis und Sie erhalten keinen Punkt.\u003Cbr\u003E\u003Cbr\u003E\n    \u003Cbutton type=\"submit\"\u003EWeiter\u003C\u002Fbutton\u003E\n  \u003C\u002Fform\u003E\n\u003C\u002Fmain\u003E\n",
                  "scrollTop": true,
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Question 1"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 213.37,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#12864e",
                      "text": "Das ist korrekt!",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Korrekt",
                  "tardy": true,
                  "timeout": "2000",
                  "skip": "${state.Frage1 == 'a'||state.Frage1 == 'c'}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 286.33,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#d6341a",
                      "text": "Das ist leider falsch.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Falsch",
                  "tardy": true,
                  "timeout": "2000",
                  "skip": "${state.Frage1 == 'b'}"
                }
              ]
            },
            {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Question 1",
              "tardy": true,
              "skip": "${state.Frage1 == 'b'}",
              "content": [
                {
                  "type": "lab.html.Form",
                  "content": "\u003Cmain\u003E\n  \u003Cform\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cp\u003EWas passiert bei einer korrekten Reaktion?\u003C\u002Fp\u003E\n    \u003Cinput type=\"radio\" name=\"Frage1\" value=\"c\"\u003E Es erscheint ein weißer Kreis und Sie erhalten keinen Punkt.\u003Cbr\u003E\n    \u003Cinput type=\"radio\" name=\"Frage1\" value=\"b\"\u003E Es erscheint entweder eine Euromünze und Sie erhalten einen Punkt oder es erscheint ein weißer Kreis und Sie erhalten keinen Punkt.\u003Cbr\u003E\n    \u003Cinput type=\"radio\" name=\"Frage1\" value=\"a\"\u003E Es erscheint eine Euromünze und Sie erhalten einen Punkt.\u003Cbr\u003E\u003Cbr\u003E\n    \u003Cbutton type=\"submit\"\u003EWeiter\u003C\u002Fbutton\u003E\n  \u003C\u002Fform\u003E\n\u003C\u002Fmain\u003E\n",
                  "scrollTop": true,
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Question 1"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 213.37,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#12864e",
                      "text": "Das ist korrekt!",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Korrekt",
                  "tardy": true,
                  "timeout": "2000",
                  "skip": "${state.Frage1 == 'a'||state.Frage1 == 'c'}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 286.33,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#d6341a",
                      "text": "Das ist leider falsch.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Falsch",
                  "tardy": true,
                  "timeout": "2000",
                  "skip": "${state.Frage1 == 'b'}"
                }
              ]
            },
            {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Question 1",
              "tardy": true,
              "skip": "${state.Frage1 == 'b'}",
              "content": [
                {
                  "type": "lab.html.Form",
                  "content": "\u003Cmain\u003E\n  \u003Cform\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cp\u003EWas passiert bei einer korrekten Reaktion?\u003C\u002Fp\u003E\n    \u003Cinput type=\"radio\" name=\"Frage1\" value=\"b\"\u003E Es erscheint entweder eine Euromünze und Sie erhalten einen Punkt oder es erscheint ein weißer Kreis und Sie erhalten keinen Punkt.\u003Cbr\u003E\n    \u003Cinput type=\"radio\" name=\"Frage1\" value=\"a\"\u003E Es erscheint eine Euromünze und Sie erhalten einen Punkt.\u003Cbr\u003E\n    \u003Cinput type=\"radio\" name=\"Frage1\" value=\"c\"\u003E Es erscheint ein weißer Kreis und Sie erhalten keinen Punkt.\u003Cbr\u003E\u003Cbr\u003E\n    \u003Cbutton type=\"submit\"\u003EWeiter\u003C\u002Fbutton\u003E\n  \u003C\u002Fform\u003E\n\u003C\u002Fmain\u003E\n",
                  "scrollTop": true,
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Question 1"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 213.37,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#12864e",
                      "text": "Das ist korrekt!",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Korrekt",
                  "tardy": true,
                  "timeout": "2000",
                  "skip": "${state.Frage1 == 'a'||state.Frage1 == 'c'}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 286.33,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#d6341a",
                      "text": "Das ist leider falsch.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {
                    "run": function anonymous(
) {
q_false = 1 // Has a question been answered "false" for third time?
}
                  },
                  "title": "Falsch",
                  "tardy": true,
                  "timeout": "2000",
                  "skip": "${state.Frage1 == 'b'}"
                }
              ]
            },
            {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Question 5: Rew Probs",
              "tardy": true,
              "skip": "${ q_false == 1 }",
              "content": [
                {
                  "type": "lab.html.Form",
                  "content": "\u003Cmain\u003E\n  \u003Cform\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cp\u003EAn welchen Postionen ist die Wahrscheinlichkeit für einen Punkt höher?\u003C\u002Fp\u003E\n    \u003Cinput type=\"radio\" name=\"Frage5\" value=\"c\"\u003E Oben links und unten rechts.\u003Cbr\u003E\n    \u003Cinput type=\"radio\" name=\"Frage5\" value=\"b\"\u003E Oben rechts und unten rechts.\u003Cbr\u003E\n    \u003Cinput type=\"radio\" name=\"Frage5\" value=\"a\"\u003E Unten links und oben rechts.\u003Cbr\u003E\u003Cbr\u003E\n    \u003Cbutton type=\"submit\"\u003EWeiter\u003C\u002Fbutton\u003E\n  \u003C\u002Fform\u003E\n\u003C\u002Fmain\u003E\n",
                  "scrollTop": true,
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Question 5: Rew Probs"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 213.37,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#12864e",
                      "text": "That is wrong.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Korrekt",
                  "tardy": true,
                  "timeout": "2000",
                  "skip": "${state.Frage5 == 'a'||state.Frage5 == 'b'}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 286.33,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#d6341a",
                      "text": "Das ist leider falsch.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Falsch",
                  "tardy": true,
                  "timeout": "2000",
                  "skip": "${state.Frage5 == 'c'}"
                }
              ]
            },
            {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Question 5",
              "tardy": true,
              "skip": "${state.Frage5 == 'c' || q_false == 1}",
              "content": [
                {
                  "type": "lab.html.Form",
                  "content": "\u003Cmain\u003E\n  \u003Cform\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cp\u003EAn welchen Postionen ist die Wahrscheinlichkeit für einen Punkt höher?\u003C\u002Fp\u003E\n    \u003Cinput type=\"radio\" name=\"Frage5\" value=\"b\"\u003E Oben rechts und unten rechts.\u003Cbr\u003E\n    \u003Cinput type=\"radio\" name=\"Frage5\" value=\"a\"\u003E Unten links und oben rechts.\u003Cbr\u003E\n    \u003Cinput type=\"radio\" name=\"Frage5\" value=\"c\"\u003E Oben links und unten rechts.\u003Cbr\u003E\u003Cbr\u003E\n    \u003Cbutton type=\"submit\"\u003EWeiter\u003C\u002Fbutton\u003E\n  \u003C\u002Fform\u003E\n\u003C\u002Fmain\u003E\n",
                  "scrollTop": true,
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Question 5"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 213.37,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#12864e",
                      "text": "Das ist korrekt!",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Korrekt",
                  "tardy": true,
                  "timeout": "2000",
                  "skip": "${state.Frage5 == 'a'||state.Frage5 == 'b'}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 286.33,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#d6341a",
                      "text": "Das ist leider falsch.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Falsch",
                  "tardy": true,
                  "timeout": "2000",
                  "skip": "${state.Frage5 == 'c'}"
                }
              ]
            },
            {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Question 5",
              "tardy": true,
              "skip": "${state.Frage5 == 'c' || q_false == 1}",
              "content": [
                {
                  "type": "lab.html.Form",
                  "content": "\u003Cmain\u003E\n  \u003Cform\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cbr\u003E\n    \u003Cp\u003EAn welchen Postionen ist die Wahrscheinlichkeit für einen Punkt höher?\u003C\u002Fp\u003E\n    \u003Cinput type=\"radio\" name=\"Frage5\" value=\"a\"\u003E Unten links und oben rechts.\u003Cbr\u003E\n    \u003Cinput type=\"radio\" name=\"Frage5\" value=\"c\"\u003E Oben links und unten rechts.\u003Cbr\u003E\n    \u003Cinput type=\"radio\" name=\"Frage5\" value=\"b\"\u003E Oben rechts und unten rechts.\u003Cbr\u003E\u003Cbr\u003E\n    \u003Cbutton type=\"submit\"\u003EWeiter\u003C\u002Fbutton\u003E\n  \u003C\u002Fform\u003E\n\u003C\u002Fmain\u003E\n",
                  "scrollTop": true,
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Question 5"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 213.37,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#12864e",
                      "text": "Das ist korrekt!",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Korrekt",
                  "tardy": true,
                  "timeout": "2000",
                  "skip": "${state.Frage5 == 'a'||state.Frage5 == 'b'}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 286.33,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#d6341a",
                      "text": "Das ist leider falsch.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {
                    "run": function anonymous(
) {
q_false = 1 // Has a question been answered "false" for third time?
}
                  },
                  "title": "Falsch",
                  "tardy": true,
                  "timeout": "2000",
                  "skip": "${state.Frage5 == 'c'}"
                }
              ]
            }
          ]
        },
        {
          "type": "lab.canvas.Screen",
          "content": [
            {
              "type": "rect",
              "left": 125,
              "top": -25,
              "angle": 0,
              "width": 1582.18,
              "height": 810.26,
              "stroke": null,
              "strokeWidth": 1,
              "fill": "black"
            },
            {
              "type": "i-text",
              "left": 0,
              "top": 250,
              "angle": 0,
              "width": 464.24,
              "height": 27.12,
              "stroke": "#ffffff",
              "strokeWidth": 0,
              "fill": "#ffffff",
              "text": "Press space bar to continue.",
              "fontStyle": "normal",
              "fontWeight": "normal",
              "fontSize": "24",
              "fontFamily": "sans-serif",
              "lineHeight": 1.16,
              "textAlign": "center"
            },
            {
              "type": "i-text",
              "left": 0,
              "top": "-100",
              "angle": 0,
              "width": 821.73,
              "height": 162,
              "stroke": null,
              "strokeWidth": 1,
              "fill": "#ffffff",
              "text": "Sie haben die Frage leider zu oft falsch beantwortet.\n\nDas Experiment ist hiermit beendet. Bitte wenden Sie sich\nan die Versuchsleitung!",
              "fontStyle": "normal",
              "fontWeight": "normal",
              "fontSize": "24",
              "fontFamily": "sans-serif",
              "lineHeight": 1.16,
              "textAlign": "center"
            }
          ],
          "viewport": [
            800,
            600
          ],
          "files": {},
          "responses": {},
          "parameters": {},
          "messageHandlers": {},
          "title": "Questions Failed",
          "tardy": true,
          "skip": true
        },
        {
          "type": "lab.flow.Sequence",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {
            "run": function anonymous(
) {
x = 0
z = 0
e = 0
h = 0
n = 0
q = 0
i = 0
}
          },
          "title": "CT",
          "content": [
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "rect",
                  "left": 125,
                  "top": -25,
                  "angle": 0,
                  "width": 1582.18,
                  "height": 810.26,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": -100,
                  "angle": 0,
                  "width": 203.42,
                  "height": 27.12,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "Let's do a little test!",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 250,
                  "angle": 0,
                  "width": 463.08,
                  "height": 27.12,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "Press space bar to continue.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress": "Space"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Instruction",
              "tardy": true
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "rect",
                  "left": 125,
                  "top": -25,
                  "angle": 0,
                  "width": 1582.18,
                  "height": 810.26,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": -100,
                  "angle": 0,
                  "width": 688.78,
                  "height": 90.04,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "In the following, you will see circles\nin two of the four boxes. You should select the corresponding key\nwith the higher chance of winning a point.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 250,
                  "angle": 0,
                  "width": 316.9,
                  "height": 27.12,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "Press space bar to continue.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress": "Space"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Instruction",
              "tardy": true
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "rect",
                  "left": 125,
                  "top": -25,
                  "angle": 0,
                  "width": 1582.18,
                  "height": 810.26,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": -211,
                  "angle": 0,
                  "width": 355.43,
                  "height": 27.12,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "Don't forget the key assignments:",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 250,
                  "angle": 0,
                  "width": 526.14,
                  "height": 27.12,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "Press space bar to continue.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "rect",
                  "left": -95,
                  "top": -36,
                  "angle": 0,
                  "width": 70,
                  "height": 70,
                  "stroke": "#ffffff",
                  "strokeWidth": 2,
                  "fill": "black"
                },
                {
                  "type": "rect",
                  "left": 95,
                  "top": -36,
                  "angle": 0,
                  "width": 70,
                  "height": 70,
                  "stroke": "#ffffff",
                  "strokeWidth": 2,
                  "fill": "black"
                },
                {
                  "type": "rect",
                  "left": -95,
                  "top": 36,
                  "angle": 0,
                  "width": 70,
                  "height": 70,
                  "stroke": "#ffffff",
                  "strokeWidth": 2,
                  "fill": "black"
                },
                {
                  "type": "rect",
                  "left": 95,
                  "top": 36,
                  "angle": 0,
                  "width": 70,
                  "height": 70,
                  "stroke": "#ffffff",
                  "strokeWidth": 2,
                  "fill": "black"
                },
                {
                  "type": "i-text",
                  "left": -95,
                  "top": -36,
                  "angle": 0,
                  "width": 20.31,
                  "height": 36.16,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "#ffffff",
                  "text": "S",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": 32,
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "i-text",
                  "left": -95,
                  "top": 36,
                  "angle": 0,
                  "width": 21.92,
                  "height": 36.16,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "#ffffff",
                  "text": "X",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": 32,
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "i-text",
                  "left": 95,
                  "top": -36,
                  "angle": 0,
                  "width": 20.98,
                  "height": 36.16,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "#ffffff",
                  "text": "K",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": 32,
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "i-text",
                  "left": 95,
                  "top": 36,
                  "angle": 0,
                  "width": 27.61,
                  "height": 36.16,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "#ffffff",
                  "text": "M",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": 32,
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "i-text",
                  "left": 250,
                  "top": -100,
                  "angle": 0,
                  "width": 106.75,
                  "height": 27.12,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "#ffffff",
                  "text": "right hand",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "i-text",
                  "left": -250,
                  "top": -100,
                  "angle": 0,
                  "width": 92.07,
                  "height": 27.12,
                  "stroke": null,
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "left hand",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "i-text",
                  "left": -250,
                  "top": -36,
                  "angle": 0,
                  "width": 137.4,
                  "height": 27.12,
                  "stroke": null,
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "middle finger",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "i-text",
                  "left": -250,
                  "top": 36,
                  "angle": 0,
                  "width": 124.08,
                  "height": 27.12,
                  "stroke": null,
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "index finger",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "i-text",
                  "left": 250,
                  "top": -36,
                  "angle": 0,
                  "width": 137.4,
                  "height": 27.12,
                  "stroke": null,
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "middle finger",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "i-text",
                  "left": 250,
                  "top": 36,
                  "angle": 0,
                  "width": 124.08,
                  "height": 27.12,
                  "stroke": null,
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "index finger",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Instruction: Tastenbelegung"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "rect",
                  "left": 125,
                  "top": -75,
                  "angle": 0,
                  "width": 1582.18,
                  "height": 810.26,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": -200,
                  "angle": 0,
                  "width": 764.36,
                  "height": 63.46,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#d6341a",
                  "text": "When two circles appear, you should always try\nto choose the one with the higher chance of winning a point!",
                  "fontStyle": "normal",
                  "fontWeight": "bold",
                  "fontSize": "26",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 250,
                  "angle": 0,
                  "width": 464.24,
                  "height": 27.12,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "Press space bar to continue.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "rect",
                  "left": -95,
                  "top": 36,
                  "angle": 0,
                  "width": 70,
                  "height": 70,
                  "stroke": "#ffffff",
                  "strokeWidth": 2,
                  "fill": "#d6341a"
                },
                {
                  "type": "rect",
                  "left": 95,
                  "top": 36,
                  "angle": 0,
                  "width": 70,
                  "height": 70,
                  "stroke": "#ffffff",
                  "strokeWidth": 2,
                  "fill": "#12864e"
                },
                {
                  "type": "rect",
                  "left": -95,
                  "top": -36,
                  "angle": 0,
                  "width": 70,
                  "height": 70,
                  "stroke": "#ffffff",
                  "strokeWidth": 2,
                  "fill": "#12864e"
                },
                {
                  "type": "rect",
                  "left": 95,
                  "top": -36,
                  "angle": 0,
                  "width": 70,
                  "height": 70,
                  "stroke": "#ffffff",
                  "strokeWidth": 2,
                  "fill": "#d6341a"
                },
                {
                  "type": "image",
                  "left": "100",
                  "top": 37,
                  "angle": 0,
                  "width": "55",
                  "height": 44.95,
                  "stroke": null,
                  "strokeWidth": 0,
                  "fill": "black",
                  "src": "${ this.files[\"white-smiley_small.png\"] }"
                },
                {
                  "type": "image",
                  "left": -90,
                  "top": "-37",
                  "angle": 0,
                  "width": 55,
                  "height": 44.95,
                  "stroke": null,
                  "strokeWidth": 0,
                  "fill": "black",
                  "src": "${ this.files[\"white-smiley_small.png\"] }"
                },
                {
                  "type": "image",
                  "left": "-89",
                  "top": "37",
                  "angle": 0,
                  "width": 55,
                  "height": 44.95,
                  "stroke": null,
                  "strokeWidth": 0,
                  "fill": "black",
                  "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                },
                {
                  "type": "image",
                  "left": "100",
                  "top": "-37",
                  "angle": 0,
                  "width": 55,
                  "height": 44.95,
                  "stroke": null,
                  "strokeWidth": 0,
                  "fill": "black",
                  "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {
                "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
              },
              "responses": {
                "keypress": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Instruction Choose Better 1",
              "tardy": true,
              "skip": "${hr_tl_br == 0}"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "rect",
                  "left": 125,
                  "top": -75,
                  "angle": 0,
                  "width": 1582.18,
                  "height": 810.26,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": -200,
                  "angle": 0,
                  "width": 764.36,
                  "height": 63.46,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#d6341a",
                  "text": "When two circles appear, you should always try\nto choose the one with the higher chance of winning a point!",
                  "fontStyle": "normal",
                  "fontWeight": "bold",
                  "fontSize": "26",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 250,
                  "angle": 0,
                  "width": 464.24,
                  "height": 27.12,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "Press space bar to continue.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "rect",
                  "left": -95,
                  "top": 36,
                  "angle": 0,
                  "width": 70,
                  "height": 70,
                  "stroke": "#ffffff",
                  "strokeWidth": 2,
                  "fill": "#12864e"
                },
                {
                  "type": "rect",
                  "left": 95,
                  "top": 36,
                  "angle": 0,
                  "width": 70,
                  "height": 70,
                  "stroke": "#ffffff",
                  "strokeWidth": 2,
                  "fill": "#d6341a"
                },
                {
                  "type": "rect",
                  "left": "-95",
                  "top": -36,
                  "angle": 0,
                  "width": 70,
                  "height": 70,
                  "stroke": "#ffffff",
                  "strokeWidth": 2,
                  "fill": "#d6341a"
                },
                {
                  "type": "rect",
                  "left": 95,
                  "top": -36,
                  "angle": 0,
                  "width": 70,
                  "height": 70,
                  "stroke": "#ffffff",
                  "strokeWidth": 2,
                  "fill": "#12864e"
                },
                {
                  "type": "image",
                  "left": "100",
                  "top": "-37",
                  "angle": 0,
                  "width": "55",
                  "height": 44.95,
                  "stroke": null,
                  "strokeWidth": 0,
                  "fill": "black",
                  "src": "${ this.files[\"white-smiley_small.png\"] }"
                },
                {
                  "type": "image",
                  "left": "-90",
                  "top": "37",
                  "angle": 0,
                  "width": 55,
                  "height": 44.95,
                  "stroke": null,
                  "strokeWidth": 0,
                  "fill": "black",
                  "src": "${ this.files[\"white-smiley_small.png\"] }"
                },
                {
                  "type": "image",
                  "left": "-90",
                  "top": "-37",
                  "angle": 0,
                  "width": 55,
                  "height": 44.95,
                  "stroke": null,
                  "strokeWidth": 0,
                  "fill": "black",
                  "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                },
                {
                  "type": "image",
                  "left": "100",
                  "top": "37",
                  "angle": 0,
                  "width": 55,
                  "height": 44.95,
                  "stroke": null,
                  "strokeWidth": 0,
                  "fill": "black",
                  "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {
                "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
              },
              "responses": {
                "keypress": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Instruction Choose Better 2",
              "tardy": true,
              "skip": "${hr_tl_br == 1}"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "rect",
                  "left": 125,
                  "top": -75,
                  "angle": 0,
                  "width": 1582.18,
                  "height": 810.26,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": -25,
                  "angle": 0,
                  "width": 434.81,
                  "height": 63.46,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#d6341a",
                  "text": "Take your time in the following trials!\nThere won´t be any time limit!!",
                  "fontStyle": "normal",
                  "fontWeight": "bold",
                  "fontSize": "26",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 250,
                  "angle": 0,
                  "width": 464.24,
                  "height": 27.12,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "Press space bar to continue.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {
                "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
              },
              "responses": {
                "keypress": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Instruction NO TIME LIMIT",
              "tardy": true
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "rect",
                  "left": 125,
                  "top": -75,
                  "angle": 0,
                  "width": 1582.18,
                  "height": 810.26,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": -25,
                  "angle": 0,
                  "width": 195.34,
                  "height": 27.12,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "Task will start momentarily...",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {
                "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
              },
              "responses": {},
              "parameters": {},
              "messageHandlers": {},
              "title": "Gleich gehts los",
              "tardy": true,
              "timeout": "2000"
            },
            {
              "type": "lab.flow.Loop",
              "templateParameters": [
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "36"
                },
                {
                  "position_x": "-95",
                  "position_y": "36",
                  "position_x2": "95",
                  "position_y2": "36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "-95",
                  "position_y2": "36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "-36"
                },
                {
                  "position_x": "-95",
                  "position_y": "36",
                  "position_x2": "95",
                  "position_y2": "-36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "-36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "-95",
                  "position_y2": "36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "-36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "-95",
                  "position_y2": "36"
                },
                {
                  "position_x": "95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "36"
                },
                {
                  "position_x": "-95",
                  "position_y": "36",
                  "position_x2": "95",
                  "position_y2": "36"
                },
                {
                  "position_x": "95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "36"
                }
              ],
              "sample": {
                "mode": "sequential",
                "n": ""
              },
              "files": {
                "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                "no1eurocoin.png": "embedded\u002F95d63f46dcb769bd416c2cc782f5c6def0fbeb89d3740e3196c6a5ae06e4553a.png",
                "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png"
              },
              "responses": {},
              "parameters": {},
              "messageHandlers": {},
              "title": "Part 1",
              "shuffleGroups": [],
              "template": {
                "type": "lab.flow.Sequence",
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "Trials",
                "content": [
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "rect",
                        "left": 75,
                        "top": 50,
                        "angle": 0,
                        "width": 1582.18,
                        "height": 810.26,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black"
                      },
                      {
                        "type": "i-text",
                        "left": -12,
                        "top": 0,
                        "angle": 0,
                        "width": 1021.55,
                        "height": 184.42,
                        "stroke": "#ffffff",
                        "strokeWidth": 0,
                        "fill": "#ffffff",
                        "text": "${ z == 1 || q == 1 || i  == 1 ? k = 800 : k = 600 }\n${ r = Math.random() }\n${ (parameters.position_x == '95' && parameters.position_y == '36') ||\n(parameters.position_x == '-95' && parameters.position_y == '-36') ? highrew = 1 : highrew = 0 } \n\n${hr_tl_br == 1 ? highrew=highrew : highrew = !highrew}",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": "24",
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {},
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "random number",
                    "tardy": true,
                    "skip": true
                  },
                  {
                    "type": "lab.flow.Sequence",
                    "files": {},
                    "responses": {},
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "Joker Thin Green",
                    "tardy": true,
                    "skip": "${ parameters.position_x2 == 0}",
                    "content": [
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 150,
                            "top": 63,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 956.31,
                            "height": 215.88,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "${ a = parameters.position_x.toString() } ${ b = parameters.position_y.toString() }\n${ Leer = ' ' }\n${ R1 = a.concat(Leer, b) }\n${ x2 = parameters.position_x2.toString() } ${ y2 = parameters.position_y2.toString() }\n${ R2 = x2.concat(Leer, y2) }\n\n${ (R1 == '-95 -36' && R2 == '95 36') || (R1 == '-95 36' && R2 == '95 -36') ? m = 0 : m = 1 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Correct responses",
                        "tardy": true,
                        "skip": true
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 10001.1,
                            "height": 10000.54,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"Background.PNG\"] }"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x }",
                            "top": "${ parameters.position_y }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x2 }",
                            "top": "${ parameters.position_y2 }",
                            "angle": 0,
                            "width": "50",
                            "height": 46.76,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "Background.PNG": "embedded\u002Ff6e74e440a74dbed53dbea3dfe3e6d9e7676ed25544b5f21e65d1ba6576cd36c.PNG"
                        },
                        "responses": {
                          "keypress(s)": "-95 -36",
                          "keypress(x)": "-95 36",
                          "keypress(k)": "95 -36",
                          "keypress(m)": "95 36",
                          "keypress(S)": "-95 -36",
                          "keypress(X)": "-95 36",
                          "keypress(K)": "95 -36",
                          "keypress(M)": "95 36"
                        },
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Stimulus_Joker",
                        "tardy": true
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x }",
                            "top": "${ parameters.position_y }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x2 }",
                            "top": "${ parameters.position_y2 }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -225,
                            "angle": 0,
                            "width": 672.89,
                            "height": 184.42,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "\n${state.response == R1 || state.response == R2 ? y = 1 : y = 0 }\n ${ state.ended_on == 'timeout' ? y = 0 : y = y }\n\n${ y == 1 ? x = 0 : x = x + 1 }\n${ state.ended_on == 'skipped' ? x = x - 1 : x = x }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "i-text",
                            "left": -25,
                            "top": 163,
                            "angle": 0,
                            "width": 916.72,
                            "height": 121.5,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'timeout' ? f = 0 : f = 1 }\n${ state.response == '95 -36' || state.response == '-95 36' ? highrew = 0 : highrew = 1 }\n\n${hr_tl_br == 1 ? highrew=highrew : highrew = !highrew}",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {
                          "keypress": "Second Press"
                        },
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Abfrage 2ter Tastendruck",
                        "timeout": "40",
                        "tardy": true,
                        "skip": "${ state.ended_on == 'timeout' }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": "#ffffff",
                            "strokeWidth": 1,
                            "fill": "#000000"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 464.27,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Please only press one key at a time.",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Doppelter Tastendruck",
                        "skip": "${ state.ended_on != 'response' }",
                        "tardy": true,
                        "timeout": "1200"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": "#ffffff",
                            "strokeWidth": 1,
                            "fill": "#000000"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 141.69,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Too slow!",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "i-text",
                            "left": 25,
                            "top": -136,
                            "angle": 0,
                            "width": 591.88,
                            "height": 27.12,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'timeout' ? q = 1 : q = 0 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Zu Schnell\u002Flangsam",
                        "skip": "${ f == 1 }",
                        "tardy": true,
                        "timeout": "1200"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 150,
                            "top": 63,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 609.08,
                            "height": 90.04,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "${ state.ended_on == 'timeout' ? z = 1 : z = 0 }\n${ y == 1 && m == 1 && highrew == 0 ? n = n + 1 : n = n }\n${ y == 1 && m == 1 && highrew == 1 ? h = h + 1 : h = h }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Addition",
                        "timeout": "1000",
                        "tardy": true,
                        "skip": true
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 154.74,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Wrong Key!",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                          "no1eurocoin.png": "embedded\u002F95d63f46dcb769bd416c2cc782f5c6def0fbeb89d3740e3196c6a5ae06e4553a.png",
                          "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png"
                        },
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "no reward",
                        "timeout": "1200",
                        "tardy": true,
                        "skip": "${ z == 1 || y == 1 || q == 1 }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x }",
                            "top": "${ parameters.position_y }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x2 }",
                            "top": "${ parameters.position_y2 }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -125,
                            "angle": 0,
                            "width": 634.91,
                            "height": 36.16,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'timeout' ? i = 1 : i = 0 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": 32,
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"smiley_small_green.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "1eurocoin.png": "embedded\u002F7f759ca75bdc64bef84579d85e9384c3c4059b4aa80415ebd58b8b2e5defb010.png",
                          "white-smiley.png": "embedded\u002F409c11c13e3236af31ed20ddc7cc0b66bad1ab5f435b40a59de658854c92045f.png",
                          "smiley_small.png": "embedded\u002Fcf62f164cbf1b495f66dcb73eac30b854ec96bc0521f7b9523a3405ab58fabc2.png",
                          "smiley_small_green.png": "embedded\u002F461ff38348b0701b6add328b041b0d329602f61238f1427d5a0575b0536093d8.png"
                        },
                        "responses": {
                          "keypress": "doublepress"
                        },
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Reward",
                        "timeout": "900",
                        "tardy": true,
                        "skip": "${ z == 1 || y == 0 || q == 1 || ( highrew == 1 && r \u003E= rewprob) || (highrew == 0 && r \u003E= (1-rewprob)) }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": "#ffffff",
                            "strokeWidth": 1,
                            "fill": "#000000"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 464.26,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Please only press one key at a time.",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -112,
                            "angle": 0,
                            "width": 710.55,
                            "height": 78.11,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'skipped' ? l = 1 : l = 0 }\n${ state.ended_on == 'timeout' ? this.parameters.p[0]++ : this.parameters.p[0] = this.parameters.p[0] }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": 32,
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Doppelter Tastendruck",
                        "skip": "${ state.ended_on != 'response' }",
                        "tardy": true,
                        "timeout": "1200"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"smiley_small_green.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "1eurocoin.png": "embedded\u002F7f759ca75bdc64bef84579d85e9384c3c4059b4aa80415ebd58b8b2e5defb010.png",
                          "smiley_small.png": "embedded\u002Fcf62f164cbf1b495f66dcb73eac30b854ec96bc0521f7b9523a3405ab58fabc2.png",
                          "smiley_small_green.png": "embedded\u002F461ff38348b0701b6add328b041b0d329602f61238f1427d5a0575b0536093d8.png"
                        },
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "ITI rew",
                        "timeout": "250",
                        "tardy": true,
                        "skip": "${ l == 1 || state.ended_on == 'timeout' }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x }",
                            "top": "${ parameters.position_y }",
                            "angle": 0,
                            "width": "50",
                            "height": 19.2,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x2 }",
                            "top": "${ parameters.position_y2 }",
                            "angle": 0,
                            "width": "50",
                            "height": 45.01,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"frowny_small_red.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png",
                          "frowny_small.png": "embedded\u002Ff75f0dd003f759dcf9177949f29db4f7c26b8c20e1735052d8e36170700139f7.png",
                          "frowny_small_red.png": "embedded\u002F75fcaf37aa5bd8004458100177b49f7d494b504f1fe5c8468fad8d2e53937f64.png"
                        },
                        "responses": {
                          "keypress": "doublepress"
                        },
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "White Point",
                        "timeout": "900",
                        "tardy": true,
                        "skip": "${ z == 1 || y == 0 || q == 1 || (highrew == 1 && r \u003C rewprob) || (highrew == 0 && r \u003C (1-rewprob)) }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": "#ffffff",
                            "strokeWidth": 1,
                            "fill": "#000000"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 464.27,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Please only press one key at a time.",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -115,
                            "angle": 0,
                            "width": 640.27,
                            "height": 36.16,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'skipped' ? l = 1 : l = 0 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": 32,
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Doppelter Tastendruck",
                        "skip": "${ state.ended_on != 'response' }",
                        "tardy": true,
                        "timeout": "1200"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": 0,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"frowny_small_red.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "eurocoin.png": "embedded\u002F9900964815a8e0cd3720da6b02e876ef60c7ced319b0eda68df95478d4066e0a.png",
                          "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                          "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png",
                          "frowny_small.png": "embedded\u002Ff75f0dd003f759dcf9177949f29db4f7c26b8c20e1735052d8e36170700139f7.png",
                          "frowny_small_red.png": "embedded\u002F75fcaf37aa5bd8004458100177b49f7d494b504f1fe5c8468fad8d2e53937f64.png"
                        },
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "ITI norew",
                        "timeout": "250",
                        "tardy": true,
                        "skip": "${ l == 1 || state.ended_on == 'timeout' }"
                      }
                    ]
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "rect",
                        "left": 150,
                        "top": 63,
                        "angle": 0,
                        "width": 1582.18,
                        "height": 810.26,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black"
                      },
                      {
                        "type": "i-text",
                        "left": 0,
                        "top": 0,
                        "angle": 0,
                        "width": 304.91,
                        "height": 27.12,
                        "stroke": "#ffffff",
                        "strokeWidth": 0,
                        "fill": "#ffffff",
                        "text": "${ x == 0 ? e = e : e = e + 1 }",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": "24",
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {},
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "total errors",
                    "tardy": true,
                    "skip": true
                  },
                  {
                    "type": "lab.flow.Sequence",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "Zu viele Fehler",
                    "tardy": true,
                    "skip": "${ x \u003C 5 }",
                    "content": [
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -25,
                            "angle": 0,
                            "width": 536.34,
                            "height": 58.58,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "You've made too many errors in a row.\n\nThe experiment will continue in a few seconds.",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Zu viele Fehler",
                        "timeout": "3000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 15.57,
                            "height": 31.64,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "3",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "28",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Instruction_Countdown",
                        "timeout": "1000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 15.57,
                            "height": 31.64,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "2",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "28",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Instruction_Countdown",
                        "timeout": "1000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 15.57,
                            "height": 31.64,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "1",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "28",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Instruction_Countdown",
                        "timeout": "1000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 15.57,
                            "height": 31.64,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "0",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "28",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Instruction_Countdown",
                        "timeout": "1000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 150,
                            "top": 63,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 492.19,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "${ state.ended_on == 'skipped' ? x = x : x = 0 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Addition",
                        "timeout": "1000",
                        "tardy": true,
                        "skip": true
                      }
                    ]
                  }
                ]
              }
            },
            {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Feedback Good CT",
              "tardy": true,
              "skip": "${ h \u003C 9 }",
              "content": [
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 164,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -162,
                      "angle": 0,
                      "width": 144.07,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Well done!",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 175,
                      "angle": 0,
                      "width": 93.45,
                      "height": 78.11,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#000000",
                      "text": "h=${h}\nn=${n}",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 261,
                      "angle": 0,
                      "width": 457.57,
                      "height": 27.12,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "triangle",
                      "left": "${600*(-0.5+h\u002F(h+n))}",
                      "top": "25",
                      "angle": 0,
                      "width": 34.5,
                      "height": 29.87,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#ffffff"
                    },
                    {
                      "type": "line",
                      "left": -109.32,
                      "top": 0,
                      "angle": 0,
                      "width": 401.83,
                      "height": 0,
                      "stroke": "#d6341a",
                      "strokeWidth": 10,
                      "fill": "rgb(0,0,0)"
                    },
                    {
                      "type": "line",
                      "left": 194.74,
                      "top": 0,
                      "angle": 0,
                      "width": 209.52,
                      "height": 0,
                      "stroke": "#12864e",
                      "strokeWidth": 10,
                      "fill": "rgb(0,0,0)"
                    },
                    {
                      "type": "image",
                      "left": "350",
                      "top": 0,
                      "angle": 0,
                      "width": "50",
                      "height": "49",
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"smiley_small_green.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": "-350",
                      "top": 0,
                      "angle": 0,
                      "width": "50",
                      "height": "49",
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"frowny_small_red.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "feedback_bad.png": "embedded\u002F3ff2f25add6008ec63f016a54e0f2692c21bd1264ac2042c6dcdcafc6a3a615f.png",
                    "smiley_small_green.png": "embedded\u002F461ff38348b0701b6add328b041b0d329602f61238f1427d5a0575b0536093d8.png",
                    "frowny_small_red.png": "embedded\u002F75fcaf37aa5bd8004458100177b49f7d494b504f1fe5c8468fad8d2e53937f64.png"
                  },
                  "responses": {
                    "keypress": ""
                  },
                  "parameters": {},
                  "messageHandlers": {
                    "run": function anonymous(
) {
o = 1
}
                  },
                  "title": "Feedback Bar Good",
                  "tardy": true
                }
              ]
            },
            {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Feedback Bad CT",
              "tardy": true,
              "skip": "${o == 1}",
              "content": [
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 164,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -162,
                      "angle": 0,
                      "width": 329.53,
                      "height": 90.04,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "That was not so good!\n\nTry again!",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 175,
                      "angle": 0,
                      "width": 93.45,
                      "height": 78.11,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#000000",
                      "text": "h=${h}\nn=${n}",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 261,
                      "angle": 0,
                      "width": 457.57,
                      "height": 27.12,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "feedback_bad.png": "embedded\u002F3ff2f25add6008ec63f016a54e0f2692c21bd1264ac2042c6dcdcafc6a3a615f.png",
                    "frowny_small_red.png": "embedded\u002F75fcaf37aa5bd8004458100177b49f7d494b504f1fe5c8468fad8d2e53937f64.png",
                    "smiley_small_green.png": "embedded\u002F461ff38348b0701b6add328b041b0d329602f61238f1427d5a0575b0536093d8.png"
                  },
                  "responses": {
                    "keypress": ""
                  },
                  "parameters": {},
                  "messageHandlers": {
                    "run": function anonymous(
) {
h = 0
n = 0
}
                  },
                  "title": "Feedback Bar Bad",
                  "tardy": true
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -75,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -200,
                      "angle": 0,
                      "width": 736.36,
                      "height": 58.58,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Remember: \nThe probability of winning a point is higher in the green boxes! ",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 464.24,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -90,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -89,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                    "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
                  },
                  "responses": {
                    "keypress": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Feedback Reward Probs 1",
                  "tardy": true,
                  "skip": "${hr_tl_br == 0}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -75,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -200,
                      "angle": 0,
                      "width": 861.05,
                      "height": 63.46,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Remember: \nThe probability of winning a point is higher in the green boxes! ",
                      "fontStyle": "normal",
                      "fontWeight": "bold",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 464.24,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -90,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -90,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                    "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
                  },
                  "responses": {
                    "keypress": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Feedback Reward Probs 2",
                  "tardy": true,
                  "skip": "${hr_tl_br == 1}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -75,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -200,
                      "angle": 0,
                      "width": 764.36,
                      "height": 63.46,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#d6341a",
                      "text": "When two circles appear, you should always try\nto choose the one with the higher chance of winning a point!",
                      "fontStyle": "normal",
                      "fontWeight": "bold",
                      "fontSize": "26",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 464.24,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -90,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -89,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                    "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
                  },
                  "responses": {
                    "keypress": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction CHOOSE BETTER REW PROB 1",
                  "tardy": true,
                  "skip": "${hr_tl_br == 0}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -75,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -200,
                      "angle": 0,
                      "width": 764.36,
                      "height": 63.46,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#d6341a",
                      "text": "When two circles appear, you should always try\nto choose the one with the higher chance of winning a point!",
                      "fontStyle": "normal",
                      "fontWeight": "bold",
                      "fontSize": "26",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 464.24,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": "-95",
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "image",
                      "left": "100",
                      "top": "-37",
                      "angle": 0,
                      "width": "55",
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": "-90",
                      "top": "37",
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": "-90",
                      "top": "-37",
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": "100",
                      "top": "37",
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                    "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
                  },
                  "responses": {
                    "keypress": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction CHOOSE BETTER REW PROB 2",
                  "tardy": true,
                  "skip": "${hr_tl_br == 1}"
                }
              ]
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "rect",
                  "left": 125,
                  "top": -75,
                  "angle": 0,
                  "width": 1582.18,
                  "height": 810.26,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": -25,
                  "angle": 0,
                  "width": 195.34,
                  "height": 27.12,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "Task will start momentarily...",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 250,
                  "angle": 0,
                  "width": 464.24,
                  "height": 27.12,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "Press space bar to continue.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {
                "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
              },
              "responses": {},
              "parameters": {},
              "messageHandlers": {},
              "title": "Gleich gehts los",
              "tardy": true,
              "timeout": "2000",
              "skip": "${ o == 1}"
            },
            {
              "type": "lab.flow.Loop",
              "templateParameters": [
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "36"
                },
                {
                  "position_x": "-95",
                  "position_y": "36",
                  "position_x2": "95",
                  "position_y2": "36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "-95",
                  "position_y2": "36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "-36"
                },
                {
                  "position_x": "-95",
                  "position_y": "36",
                  "position_x2": "95",
                  "position_y2": "-36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "-36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "-95",
                  "position_y2": "36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "-36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "-95",
                  "position_y2": "36"
                },
                {
                  "position_x": "95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "36"
                },
                {
                  "position_x": "-95",
                  "position_y": "36",
                  "position_x2": "95",
                  "position_y2": "36"
                },
                {
                  "position_x": "95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "36"
                }
              ],
              "sample": {
                "mode": "sequential",
                "n": ""
              },
              "files": {
                "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                "no1eurocoin.png": "embedded\u002F95d63f46dcb769bd416c2cc782f5c6def0fbeb89d3740e3196c6a5ae06e4553a.png",
                "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png"
              },
              "responses": {},
              "parameters": {},
              "messageHandlers": {},
              "title": "Part 2",
              "tardy": true,
              "skip": "${ o == 1}",
              "shuffleGroups": [],
              "template": {
                "type": "lab.flow.Sequence",
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "Trials",
                "content": [
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "rect",
                        "left": 75,
                        "top": 50,
                        "angle": 0,
                        "width": 1582.18,
                        "height": 810.26,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black"
                      },
                      {
                        "type": "i-text",
                        "left": -12,
                        "top": 0,
                        "angle": 0,
                        "width": 1021.55,
                        "height": 184.42,
                        "stroke": "#ffffff",
                        "strokeWidth": 0,
                        "fill": "#ffffff",
                        "text": "${ z == 1 || q == 1 || i  == 1 ? k = 800 : k = 600 }\n${ r = Math.random() }\n${ (parameters.position_x == '95' && parameters.position_y == '36') ||\n(parameters.position_x == '-95' && parameters.position_y == '-36') ? highrew = 1 : highrew = 0 } \n\n${hr_tl_br == 1 ? highrew=highrew : highrew = !highrew}",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": "24",
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {},
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "random number",
                    "tardy": true,
                    "skip": true
                  },
                  {
                    "type": "lab.flow.Sequence",
                    "files": {},
                    "responses": {},
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "Joker Thin Green",
                    "tardy": true,
                    "skip": "${ parameters.position_x2 == 0}",
                    "content": [
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 150,
                            "top": 63,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 956.31,
                            "height": 215.88,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "${ a = parameters.position_x.toString() } ${ b = parameters.position_y.toString() }\n${ Leer = ' ' }\n${ R1 = a.concat(Leer, b) }\n${ x2 = parameters.position_x2.toString() } ${ y2 = parameters.position_y2.toString() }\n${ R2 = x2.concat(Leer, y2) }\n\n${ (R1 == '-95 -36' && R2 == '95 36') || (R1 == '-95 36' && R2 == '95 -36') ? m = 0 : m = 1 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Correct responses",
                        "tardy": true,
                        "skip": true
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 10001.1,
                            "height": 10000.54,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"Background.PNG\"] }"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x }",
                            "top": "${ parameters.position_y }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x2 }",
                            "top": "${ parameters.position_y2 }",
                            "angle": 0,
                            "width": "50",
                            "height": 46.76,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "Background.PNG": "embedded\u002Ff6e74e440a74dbed53dbea3dfe3e6d9e7676ed25544b5f21e65d1ba6576cd36c.PNG"
                        },
                        "responses": {
                          "keypress(s)": "-95 -36",
                          "keypress(x)": "-95 36",
                          "keypress(k)": "95 -36",
                          "keypress(m)": "95 36",
                          "keypress(S)": "-95 -36",
                          "keypress(X)": "-95 36",
                          "keypress(K)": "95 -36",
                          "keypress(M)": "95 36"
                        },
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Stimulus_Joker",
                        "tardy": true
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x }",
                            "top": "${ parameters.position_y }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x2 }",
                            "top": "${ parameters.position_y2 }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -225,
                            "angle": 0,
                            "width": 672.89,
                            "height": 184.42,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "\n${state.response == R1 || state.response == R2 ? y = 1 : y = 0 }\n ${ state.ended_on == 'timeout' ? y = 0 : y = y }\n\n${ y == 1 ? x = 0 : x = x + 1 }\n${ state.ended_on == 'skipped' ? x = x - 1 : x = x }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "i-text",
                            "left": -25,
                            "top": 163,
                            "angle": 0,
                            "width": 916.72,
                            "height": 121.5,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'timeout' ? f = 0 : f = 1 }\n${ state.response == '95 -36' || state.response == '-95 36' ? highrew = 0 : highrew = 1 }\n\n${hr_tl_br == 1 ? highrew=highrew : highrew = !highrew}",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {
                          "keypress": "Second Press"
                        },
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Abfrage 2ter Tastendruck",
                        "timeout": "40",
                        "tardy": true,
                        "skip": "${ state.ended_on == 'timeout' }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": "#ffffff",
                            "strokeWidth": 1,
                            "fill": "#000000"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 464.27,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Please only press one key at a time.",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Doppelter Tastendruck",
                        "skip": "${ state.ended_on != 'response' }",
                        "tardy": true,
                        "timeout": "1200"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": "#ffffff",
                            "strokeWidth": 1,
                            "fill": "#000000"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 141.69,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Too slow!",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "i-text",
                            "left": 25,
                            "top": -136,
                            "angle": 0,
                            "width": 591.88,
                            "height": 27.12,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'timeout' ? q = 1 : q = 0 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Zu Schnell\u002Flangsam",
                        "skip": "${ f == 1 }",
                        "tardy": true,
                        "timeout": "1200"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 150,
                            "top": 63,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 609.08,
                            "height": 90.04,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "${ state.ended_on == 'timeout' ? z = 1 : z = 0 }\n${ y == 1 && m == 1 && highrew == 0 ? n = n + 1 : n = n }\n${ y == 1 && m == 1 && highrew == 1 ? h = h + 1 : h = h }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Addition",
                        "timeout": "1000",
                        "tardy": true,
                        "skip": true
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 154.74,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Wrong Key!",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                          "no1eurocoin.png": "embedded\u002F95d63f46dcb769bd416c2cc782f5c6def0fbeb89d3740e3196c6a5ae06e4553a.png",
                          "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png"
                        },
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "no reward",
                        "timeout": "1200",
                        "tardy": true,
                        "skip": "${ z == 1 || y == 1 || q == 1 }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x }",
                            "top": "${ parameters.position_y }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x2 }",
                            "top": "${ parameters.position_y2 }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -125,
                            "angle": 0,
                            "width": 634.91,
                            "height": 36.16,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'timeout' ? i = 1 : i = 0 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": 32,
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"smiley_small_green.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "1eurocoin.png": "embedded\u002F7f759ca75bdc64bef84579d85e9384c3c4059b4aa80415ebd58b8b2e5defb010.png",
                          "white-smiley.png": "embedded\u002F409c11c13e3236af31ed20ddc7cc0b66bad1ab5f435b40a59de658854c92045f.png",
                          "smiley_small.png": "embedded\u002Fcf62f164cbf1b495f66dcb73eac30b854ec96bc0521f7b9523a3405ab58fabc2.png",
                          "smiley_small_green.png": "embedded\u002F461ff38348b0701b6add328b041b0d329602f61238f1427d5a0575b0536093d8.png"
                        },
                        "responses": {
                          "keypress": "doublepress"
                        },
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Reward",
                        "timeout": "900",
                        "tardy": true,
                        "skip": "${ z == 1 || y == 0 || q == 1 || ( highrew == 1 && r \u003E= rewprob) || (highrew == 0 && r \u003E= (1-rewprob)) }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": "#ffffff",
                            "strokeWidth": 1,
                            "fill": "#000000"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 464.26,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Please only press one key at a time.",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -112,
                            "angle": 0,
                            "width": 710.55,
                            "height": 78.11,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'skipped' ? l = 1 : l = 0 }\n${ state.ended_on == 'timeout' ? this.parameters.p[0]++ : this.parameters.p[0] = this.parameters.p[0] }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": 32,
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Doppelter Tastendruck",
                        "skip": "${ state.ended_on != 'response' }",
                        "tardy": true,
                        "timeout": "1200"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"smiley_small_green.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "1eurocoin.png": "embedded\u002F7f759ca75bdc64bef84579d85e9384c3c4059b4aa80415ebd58b8b2e5defb010.png",
                          "smiley_small.png": "embedded\u002Fcf62f164cbf1b495f66dcb73eac30b854ec96bc0521f7b9523a3405ab58fabc2.png",
                          "smiley_small_green.png": "embedded\u002F461ff38348b0701b6add328b041b0d329602f61238f1427d5a0575b0536093d8.png"
                        },
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "ITI rew",
                        "timeout": "250",
                        "tardy": true,
                        "skip": "${ l == 1 || state.ended_on == 'timeout' }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x }",
                            "top": "${ parameters.position_y }",
                            "angle": 0,
                            "width": "50",
                            "height": 19.2,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x2 }",
                            "top": "${ parameters.position_y2 }",
                            "angle": 0,
                            "width": "50",
                            "height": 45.01,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"frowny_small_red.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png",
                          "frowny_small.png": "embedded\u002Ff75f0dd003f759dcf9177949f29db4f7c26b8c20e1735052d8e36170700139f7.png",
                          "frowny_small_red.png": "embedded\u002F75fcaf37aa5bd8004458100177b49f7d494b504f1fe5c8468fad8d2e53937f64.png"
                        },
                        "responses": {
                          "keypress": "doublepress"
                        },
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "White Point",
                        "timeout": "900",
                        "tardy": true,
                        "skip": "${ z == 1 || y == 0 || q == 1 || (highrew == 1 && r \u003C rewprob) || (highrew == 0 && r \u003C (1-rewprob)) }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": "#ffffff",
                            "strokeWidth": 1,
                            "fill": "#000000"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 464.27,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Please only press one key at a time.",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -115,
                            "angle": 0,
                            "width": 640.27,
                            "height": 36.16,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'skipped' ? l = 1 : l = 0 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": 32,
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Doppelter Tastendruck",
                        "skip": "${ state.ended_on != 'response' }",
                        "tardy": true,
                        "timeout": "1200"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": 0,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"frowny_small_red.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "eurocoin.png": "embedded\u002F9900964815a8e0cd3720da6b02e876ef60c7ced319b0eda68df95478d4066e0a.png",
                          "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                          "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png",
                          "frowny_small.png": "embedded\u002Ff75f0dd003f759dcf9177949f29db4f7c26b8c20e1735052d8e36170700139f7.png",
                          "frowny_small_red.png": "embedded\u002F75fcaf37aa5bd8004458100177b49f7d494b504f1fe5c8468fad8d2e53937f64.png"
                        },
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "ITI norew",
                        "timeout": "250",
                        "tardy": true,
                        "skip": "${ l == 1 || state.ended_on == 'timeout' }"
                      }
                    ]
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "rect",
                        "left": 150,
                        "top": 63,
                        "angle": 0,
                        "width": 1582.18,
                        "height": 810.26,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black"
                      },
                      {
                        "type": "i-text",
                        "left": 0,
                        "top": 0,
                        "angle": 0,
                        "width": 304.91,
                        "height": 27.12,
                        "stroke": "#ffffff",
                        "strokeWidth": 0,
                        "fill": "#ffffff",
                        "text": "${ x == 0 ? e = e : e = e + 1 }",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": "24",
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {},
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "total errors",
                    "tardy": true,
                    "skip": true
                  },
                  {
                    "type": "lab.flow.Sequence",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "Zu viele Fehler",
                    "tardy": true,
                    "skip": "${ x \u003C 5 }",
                    "content": [
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -25,
                            "angle": 0,
                            "width": 536.34,
                            "height": 58.58,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "You've made too many errors in a row.\n\nThe experiment will continue in a few seconds.",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Zu viele Fehler",
                        "timeout": "3000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 15.57,
                            "height": 31.64,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "3",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "28",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Instruction_Countdown",
                        "timeout": "1000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 15.57,
                            "height": 31.64,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "2",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "28",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Instruction_Countdown",
                        "timeout": "1000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 15.57,
                            "height": 31.64,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "1",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "28",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Instruction_Countdown",
                        "timeout": "1000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 15.57,
                            "height": 31.64,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "0",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "28",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Instruction_Countdown",
                        "timeout": "1000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 150,
                            "top": 63,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 492.19,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "${ state.ended_on == 'skipped' ? x = x : x = 0 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Addition",
                        "timeout": "1000",
                        "tardy": true,
                        "skip": true
                      }
                    ]
                  }
                ]
              }
            },
            {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Feedback Good CT",
              "tardy": true,
              "skip": "${ h \u003C 9 || o == 1}",
              "content": [
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 164,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -162,
                      "angle": 0,
                      "width": 144.07,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Well done!",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 175,
                      "angle": 0,
                      "width": 93.45,
                      "height": 78.11,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#000000",
                      "text": "h=${h}\nn=${n}",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 261,
                      "angle": 0,
                      "width": 457.57,
                      "height": 27.12,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "triangle",
                      "left": "${600*(-0.5+h\u002F(h+n))}",
                      "top": "25",
                      "angle": 0,
                      "width": 34.5,
                      "height": 29.87,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#ffffff"
                    },
                    {
                      "type": "line",
                      "left": -109.32,
                      "top": 0,
                      "angle": 0,
                      "width": 401.83,
                      "height": 0,
                      "stroke": "#d6341a",
                      "strokeWidth": 10,
                      "fill": "rgb(0,0,0)"
                    },
                    {
                      "type": "line",
                      "left": 194.74,
                      "top": 0,
                      "angle": 0,
                      "width": 209.52,
                      "height": 0,
                      "stroke": "#12864e",
                      "strokeWidth": 10,
                      "fill": "rgb(0,0,0)"
                    },
                    {
                      "type": "image",
                      "left": "350",
                      "top": 0,
                      "angle": 0,
                      "width": "50",
                      "height": "49",
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"smiley_small_green.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": "-350",
                      "top": 0,
                      "angle": 0,
                      "width": "50",
                      "height": "49",
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"frowny_small_red.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "feedback_bad.png": "embedded\u002F3ff2f25add6008ec63f016a54e0f2692c21bd1264ac2042c6dcdcafc6a3a615f.png",
                    "smiley_small_green.png": "embedded\u002F461ff38348b0701b6add328b041b0d329602f61238f1427d5a0575b0536093d8.png",
                    "frowny_small_red.png": "embedded\u002F75fcaf37aa5bd8004458100177b49f7d494b504f1fe5c8468fad8d2e53937f64.png"
                  },
                  "responses": {
                    "keypress": ""
                  },
                  "parameters": {},
                  "messageHandlers": {
                    "run": function anonymous(
) {
o = 1
}
                  },
                  "title": "Feedback Bar Good",
                  "tardy": true
                }
              ]
            },
            {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Feedback Bad CT",
              "tardy": true,
              "skip": "${o == 1}",
              "content": [
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 164,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -162,
                      "angle": 0,
                      "width": 329.53,
                      "height": 90.04,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "That was not that great, unfortunately!\n\nTry again!",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 175,
                      "angle": 0,
                      "width": 93.45,
                      "height": 78.11,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#000000",
                      "text": "h=${h}\nn=${n}",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 261,
                      "angle": 0,
                      "width": 457.57,
                      "height": 27.12,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "feedback_bad.png": "embedded\u002F3ff2f25add6008ec63f016a54e0f2692c21bd1264ac2042c6dcdcafc6a3a615f.png",
                    "frowny_small_red.png": "embedded\u002F75fcaf37aa5bd8004458100177b49f7d494b504f1fe5c8468fad8d2e53937f64.png",
                    "smiley_small_green.png": "embedded\u002F461ff38348b0701b6add328b041b0d329602f61238f1427d5a0575b0536093d8.png"
                  },
                  "responses": {
                    "keypress": ""
                  },
                  "parameters": {},
                  "messageHandlers": {
                    "run": function anonymous(
) {
h = 0
n = 0
}
                  },
                  "title": "Feedback Bar Bad",
                  "tardy": true
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -75,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -200,
                      "angle": 0,
                      "width": 736.36,
                      "height": 58.58,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Don't forget:\nThe point win probability is highest in the green boxes!",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 464.24,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -90,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -89,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                    "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
                  },
                  "responses": {
                    "keypress": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Feedback Reward Probs 1",
                  "tardy": true,
                  "skip": "${hr_tl_br == 0}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -75,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -200,
                      "angle": 0,
                      "width": 861.05,
                      "height": 63.46,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Remember: \nThe probability of winning a point is higher in the green boxes! ",
                      "fontStyle": "normal",
                      "fontWeight": "bold",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 464.24,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -90,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -90,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                    "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
                  },
                  "responses": {
                    "keypress": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Feedback Reward Probs 2",
                  "tardy": true,
                  "skip": "${hr_tl_br == 1}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -75,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -200,
                      "angle": 0,
                      "width": 764.36,
                      "height": 63.46,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#d6341a",
                      "text": "When two circles appear, you should always try\nto choose the one with the higher chance of winning a point!",
                      "fontStyle": "normal",
                      "fontWeight": "bold",
                      "fontSize": "26",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 464.24,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -90,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": -89,
                      "top": 37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": 100,
                      "top": -37,
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                    "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
                  },
                  "responses": {
                    "keypress": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction CHOOSE BETTER REW PROB 1",
                  "tardy": true,
                  "skip": "${hr_tl_br == 0}"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 125,
                      "top": -75,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -200,
                      "angle": 0,
                      "width": 764.36,
                      "height": 63.46,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#d6341a",
                      "text": "When two circles appear, you should always try\nto choose the one with the higher chance of winning a point!",
                      "fontStyle": "normal",
                      "fontWeight": "bold",
                      "fontSize": "26",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 250,
                      "angle": 0,
                      "width": 464.24,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "rect",
                      "left": -95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": 36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": "-95",
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#d6341a"
                    },
                    {
                      "type": "rect",
                      "left": 95,
                      "top": -36,
                      "angle": 0,
                      "width": 70,
                      "height": 70,
                      "stroke": "#ffffff",
                      "strokeWidth": 2,
                      "fill": "#12864e"
                    },
                    {
                      "type": "image",
                      "left": "100",
                      "top": "-37",
                      "angle": 0,
                      "width": "55",
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": "-90",
                      "top": "37",
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"white-smiley_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": "-90",
                      "top": "-37",
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": "100",
                      "top": "37",
                      "angle": 0,
                      "width": 55,
                      "height": 44.95,
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"sad-smiley_black_small.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                    "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
                  },
                  "responses": {
                    "keypress": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Instruction CHOOSE BETTER REW PROB 2",
                  "tardy": true,
                  "skip": "${hr_tl_br == 1}"
                }
              ]
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "rect",
                  "left": 125,
                  "top": -75,
                  "angle": 0,
                  "width": 1582.18,
                  "height": 810.26,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": -25,
                  "angle": 0,
                  "width": 195.34,
                  "height": 27.12,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "Task will start momentarily...",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 250,
                  "angle": 0,
                  "width": 464.24,
                  "height": 27.12,
                  "stroke": "#ffffff",
                  "strokeWidth": 0,
                  "fill": "#ffffff",
                  "text": "Press space bar to continue.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "24",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {
                "white-smiley_small.png": "embedded\u002Ff8685301f765f6c55243ee451f2b7443c570cf7847845a20b543134538b8a452.png",
                "sad-smiley_black_small.png": "embedded\u002F5bd83446ecd3b3a8e083cb64bdea30ed00bf854e4432f8e0308efc62da22d3e9.png"
              },
              "responses": {},
              "parameters": {},
              "messageHandlers": {},
              "title": "Gleich gehts los",
              "tardy": true,
              "timeout": "2000",
              "skip": "${ o == 1 }"
            },
            {
              "type": "lab.flow.Loop",
              "templateParameters": [
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "36"
                },
                {
                  "position_x": "-95",
                  "position_y": "36",
                  "position_x2": "95",
                  "position_y2": "36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "-95",
                  "position_y2": "36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "-36"
                },
                {
                  "position_x": "-95",
                  "position_y": "36",
                  "position_x2": "95",
                  "position_y2": "-36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "-36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "-95",
                  "position_y2": "36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "-36"
                },
                {
                  "position_x": "-95",
                  "position_y": "-36",
                  "position_x2": "-95",
                  "position_y2": "36"
                },
                {
                  "position_x": "95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "36"
                },
                {
                  "position_x": "-95",
                  "position_y": "36",
                  "position_x2": "95",
                  "position_y2": "36"
                },
                {
                  "position_x": "95",
                  "position_y": "-36",
                  "position_x2": "95",
                  "position_y2": "36"
                }
              ],
              "sample": {
                "mode": "sequential",
                "n": ""
              },
              "files": {
                "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                "no1eurocoin.png": "embedded\u002F95d63f46dcb769bd416c2cc782f5c6def0fbeb89d3740e3196c6a5ae06e4553a.png",
                "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png"
              },
              "responses": {},
              "parameters": {},
              "messageHandlers": {},
              "title": "Part 3",
              "tardy": true,
              "skip": "${ o == 1 }",
              "shuffleGroups": [],
              "template": {
                "type": "lab.flow.Sequence",
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "Trials",
                "content": [
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "rect",
                        "left": 75,
                        "top": 50,
                        "angle": 0,
                        "width": 1582.18,
                        "height": 810.26,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black"
                      },
                      {
                        "type": "i-text",
                        "left": -12,
                        "top": 0,
                        "angle": 0,
                        "width": 1021.55,
                        "height": 184.42,
                        "stroke": "#ffffff",
                        "strokeWidth": 0,
                        "fill": "#ffffff",
                        "text": "${ z == 1 || q == 1 || i  == 1 ? k = 800 : k = 600 }\n${ r = Math.random() }\n${ (parameters.position_x == '95' && parameters.position_y == '36') ||\n(parameters.position_x == '-95' && parameters.position_y == '-36') ? highrew = 1 : highrew = 0 } \n\n${hr_tl_br == 1 ? highrew=highrew : highrew = !highrew}",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": "24",
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {},
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "random number",
                    "tardy": true,
                    "skip": true
                  },
                  {
                    "type": "lab.flow.Sequence",
                    "files": {},
                    "responses": {},
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "Joker Thin Green",
                    "tardy": true,
                    "skip": "${ parameters.position_x2 == 0}",
                    "content": [
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 150,
                            "top": 63,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 956.31,
                            "height": 215.88,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "${ a = parameters.position_x.toString() } ${ b = parameters.position_y.toString() }\n${ Leer = ' ' }\n${ R1 = a.concat(Leer, b) }\n${ x2 = parameters.position_x2.toString() } ${ y2 = parameters.position_y2.toString() }\n${ R2 = x2.concat(Leer, y2) }\n\n${ (R1 == '-95 -36' && R2 == '95 36') || (R1 == '-95 36' && R2 == '95 -36') ? m = 0 : m = 1 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Correct responses",
                        "tardy": true,
                        "skip": true
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 10001.1,
                            "height": 10000.54,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"Background.PNG\"] }"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x }",
                            "top": "${ parameters.position_y }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x2 }",
                            "top": "${ parameters.position_y2 }",
                            "angle": 0,
                            "width": "50",
                            "height": 46.76,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "Background.PNG": "embedded\u002Ff6e74e440a74dbed53dbea3dfe3e6d9e7676ed25544b5f21e65d1ba6576cd36c.PNG"
                        },
                        "responses": {
                          "keypress(s)": "-95 -36",
                          "keypress(x)": "-95 36",
                          "keypress(k)": "95 -36",
                          "keypress(m)": "95 36",
                          "keypress(S)": "-95 -36",
                          "keypress(X)": "-95 36",
                          "keypress(K)": "95 -36",
                          "keypress(M)": "95 36"
                        },
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Stimulus_Joker",
                        "tardy": true
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x }",
                            "top": "${ parameters.position_y }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x2 }",
                            "top": "${ parameters.position_y2 }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -225,
                            "angle": 0,
                            "width": 672.89,
                            "height": 184.42,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "\n${state.response == R1 || state.response == R2 ? y = 1 : y = 0 }\n ${ state.ended_on == 'timeout' ? y = 0 : y = y }\n\n${ y == 1 ? x = 0 : x = x + 1 }\n${ state.ended_on == 'skipped' ? x = x - 1 : x = x }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "i-text",
                            "left": -25,
                            "top": 163,
                            "angle": 0,
                            "width": 916.72,
                            "height": 121.5,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'timeout' ? f = 0 : f = 1 }\n${ state.response == '95 -36' || state.response == '-95 36' ? highrew = 0 : highrew = 1 }\n\n${hr_tl_br == 1 ? highrew=highrew : highrew = !highrew}",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {
                          "keypress": "Second Press"
                        },
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Abfrage 2ter Tastendruck",
                        "timeout": "40",
                        "tardy": true,
                        "skip": "${ state.ended_on == 'timeout' }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": "#ffffff",
                            "strokeWidth": 1,
                            "fill": "#000000"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 464.27,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Please only press one key at a time.",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Doppelter Tastendruck",
                        "skip": "${ state.ended_on != 'response' }",
                        "tardy": true,
                        "timeout": "1200"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": "#ffffff",
                            "strokeWidth": 1,
                            "fill": "#000000"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 141.69,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Too slow!",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "i-text",
                            "left": 25,
                            "top": -136,
                            "angle": 0,
                            "width": 591.88,
                            "height": 27.12,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'timeout' ? q = 1 : q = 0 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Zu Schnell\u002Flangsam",
                        "skip": "${ f == 1 }",
                        "tardy": true,
                        "timeout": "1200"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 150,
                            "top": 63,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 609.08,
                            "height": 90.04,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "${ state.ended_on == 'timeout' ? z = 1 : z = 0 }\n${ y == 1 && m == 1 && highrew == 0 ? n = n + 1 : n = n }\n${ y == 1 && m == 1 && highrew == 1 ? h = h + 1 : h = h }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Addition",
                        "timeout": "1000",
                        "tardy": true,
                        "skip": true
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 154.74,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Wrong Key!",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                          "no1eurocoin.png": "embedded\u002F95d63f46dcb769bd416c2cc782f5c6def0fbeb89d3740e3196c6a5ae06e4553a.png",
                          "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png"
                        },
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "no reward",
                        "timeout": "1200",
                        "tardy": true,
                        "skip": "${ z == 1 || y == 1 || q == 1 }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x }",
                            "top": "${ parameters.position_y }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x2 }",
                            "top": "${ parameters.position_y2 }",
                            "angle": 0,
                            "width": 50,
                            "height": 50,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -125,
                            "angle": 0,
                            "width": 634.91,
                            "height": 36.16,
                            "stroke": "#000000",
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'timeout' ? i = 1 : i = 0 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": 32,
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"smiley_small_green.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "1eurocoin.png": "embedded\u002F7f759ca75bdc64bef84579d85e9384c3c4059b4aa80415ebd58b8b2e5defb010.png",
                          "white-smiley.png": "embedded\u002F409c11c13e3236af31ed20ddc7cc0b66bad1ab5f435b40a59de658854c92045f.png",
                          "smiley_small.png": "embedded\u002Fcf62f164cbf1b495f66dcb73eac30b854ec96bc0521f7b9523a3405ab58fabc2.png",
                          "smiley_small_green.png": "embedded\u002F461ff38348b0701b6add328b041b0d329602f61238f1427d5a0575b0536093d8.png"
                        },
                        "responses": {
                          "keypress": "doublepress"
                        },
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Reward",
                        "timeout": "900",
                        "tardy": true,
                        "skip": "${ z == 1 || y == 0 || q == 1 || ( highrew == 1 && r \u003E= rewprob) || (highrew == 0 && r \u003E= (1-rewprob)) }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": "#ffffff",
                            "strokeWidth": 1,
                            "fill": "#000000"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 464.26,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Please only press one key at a time.",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -112,
                            "angle": 0,
                            "width": 710.55,
                            "height": 78.11,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'skipped' ? l = 1 : l = 0 }\n${ state.ended_on == 'timeout' ? this.parameters.p[0]++ : this.parameters.p[0] = this.parameters.p[0] }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": 32,
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Doppelter Tastendruck",
                        "skip": "${ state.ended_on != 'response' }",
                        "tardy": true,
                        "timeout": "1200"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"smiley_small_green.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "1eurocoin.png": "embedded\u002F7f759ca75bdc64bef84579d85e9384c3c4059b4aa80415ebd58b8b2e5defb010.png",
                          "smiley_small.png": "embedded\u002Fcf62f164cbf1b495f66dcb73eac30b854ec96bc0521f7b9523a3405ab58fabc2.png",
                          "smiley_small_green.png": "embedded\u002F461ff38348b0701b6add328b041b0d329602f61238f1427d5a0575b0536093d8.png"
                        },
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "ITI rew",
                        "timeout": "250",
                        "tardy": true,
                        "skip": "${ l == 1 || state.ended_on == 'timeout' }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x }",
                            "top": "${ parameters.position_y }",
                            "angle": 0,
                            "width": "50",
                            "height": 19.2,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "circle",
                            "left": "${ parameters.position_x2 }",
                            "top": "${ parameters.position_y2 }",
                            "angle": 0,
                            "width": "50",
                            "height": 45.01,
                            "stroke": "#00aa00",
                            "strokeWidth": 1,
                            "fill": "#00aa00"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"frowny_small_red.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png",
                          "frowny_small.png": "embedded\u002Ff75f0dd003f759dcf9177949f29db4f7c26b8c20e1735052d8e36170700139f7.png",
                          "frowny_small_red.png": "embedded\u002F75fcaf37aa5bd8004458100177b49f7d494b504f1fe5c8468fad8d2e53937f64.png"
                        },
                        "responses": {
                          "keypress": "doublepress"
                        },
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "White Point",
                        "timeout": "900",
                        "tardy": true,
                        "skip": "${ z == 1 || y == 0 || q == 1 || (highrew == 1 && r \u003C rewprob) || (highrew == 0 && r \u003C (1-rewprob)) }"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": "#ffffff",
                            "strokeWidth": 1,
                            "fill": "#000000"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 464.27,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "Please only press one key at a time.",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -115,
                            "angle": 0,
                            "width": 640.27,
                            "height": 36.16,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "#000000",
                            "text": "${ state.ended_on == 'skipped' ? l = 1 : l = 0 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": 32,
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Doppelter Tastendruck",
                        "skip": "${ state.ended_on != 'response' }",
                        "tardy": true,
                        "timeout": "1200"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": 0,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "image",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": "50",
                            "height": "49",
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "black",
                            "src": "${ this.files[\"frowny_small_red.png\"] }"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {
                          "eurocoin.png": "embedded\u002F9900964815a8e0cd3720da6b02e876ef60c7ced319b0eda68df95478d4066e0a.png",
                          "1eurocoin.png": "embedded\u002F76a4317e0c9f7f70969a32dd313cc6e533930069bfc3e6e1bc12797d5f79e583.png",
                          "whitepoint.png": "embedded\u002Ffd9d3b06dbfa2ecf3464d0cdef33993623c5e87213bf7f2b57934be1e194e616.png",
                          "frowny_small.png": "embedded\u002Ff75f0dd003f759dcf9177949f29db4f7c26b8c20e1735052d8e36170700139f7.png",
                          "frowny_small_red.png": "embedded\u002F75fcaf37aa5bd8004458100177b49f7d494b504f1fe5c8468fad8d2e53937f64.png"
                        },
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "ITI norew",
                        "timeout": "250",
                        "tardy": true,
                        "skip": "${ l == 1 || state.ended_on == 'timeout' }"
                      }
                    ]
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "rect",
                        "left": 150,
                        "top": 63,
                        "angle": 0,
                        "width": 1582.18,
                        "height": 810.26,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black"
                      },
                      {
                        "type": "i-text",
                        "left": 0,
                        "top": 0,
                        "angle": 0,
                        "width": 304.91,
                        "height": 27.12,
                        "stroke": "#ffffff",
                        "strokeWidth": 0,
                        "fill": "#ffffff",
                        "text": "${ x == 0 ? e = e : e = e + 1 }",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": "24",
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {},
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "total errors",
                    "tardy": true,
                    "skip": true
                  },
                  {
                    "type": "lab.flow.Sequence",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "Zu viele Fehler",
                    "tardy": true,
                    "skip": "${ x \u003C 5 }",
                    "content": [
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 125,
                            "top": -25,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": -25,
                            "angle": 0,
                            "width": 536.34,
                            "height": 58.58,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "You've made too many errors in a row.\n\nThe experiment will continue in a few seconds.",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Zu viele Fehler",
                        "timeout": "3000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 15.57,
                            "height": 31.64,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "3",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "28",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Instruction_Countdown",
                        "timeout": "1000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 15.57,
                            "height": 31.64,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "2",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "28",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Instruction_Countdown",
                        "timeout": "1000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 15.57,
                            "height": 31.64,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "1",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "28",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Instruction_Countdown",
                        "timeout": "1000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": "125",
                            "top": "-25",
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": -36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": -95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "rect",
                            "left": 95,
                            "top": 36,
                            "angle": 0,
                            "width": 70,
                            "height": 70,
                            "stroke": "#ffffff",
                            "strokeWidth": 2,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 15.57,
                            "height": 31.64,
                            "stroke": null,
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "0",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "28",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Instruction_Countdown",
                        "timeout": "1000"
                      },
                      {
                        "type": "lab.canvas.Screen",
                        "content": [
                          {
                            "type": "rect",
                            "left": 150,
                            "top": 63,
                            "angle": 0,
                            "width": 1582.18,
                            "height": 810.26,
                            "stroke": null,
                            "strokeWidth": 1,
                            "fill": "black"
                          },
                          {
                            "type": "i-text",
                            "left": 0,
                            "top": 0,
                            "angle": 0,
                            "width": 492.19,
                            "height": 27.12,
                            "stroke": "#ffffff",
                            "strokeWidth": 0,
                            "fill": "#ffffff",
                            "text": "${ state.ended_on == 'skipped' ? x = x : x = 0 }",
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "24",
                            "fontFamily": "sans-serif",
                            "lineHeight": 1.16,
                            "textAlign": "center"
                          }
                        ],
                        "viewport": [
                          800,
                          600
                        ],
                        "files": {},
                        "responses": {},
                        "parameters": {},
                        "messageHandlers": {},
                        "title": "Addition",
                        "timeout": "1000",
                        "tardy": true,
                        "skip": true
                      }
                    ]
                  }
                ]
              }
            },
            {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Feedback Good CT",
              "tardy": true,
              "skip": "${ h \u003C 9 || o == 1}",
              "content": [
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "rect",
                      "left": 164,
                      "top": -25,
                      "angle": 0,
                      "width": 1582.18,
                      "height": 810.26,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": -162,
                      "angle": 0,
                      "width": 144.07,
                      "height": 27.12,
                      "stroke": "#ffffff",
                      "strokeWidth": 0,
                      "fill": "#ffffff",
                      "text": "Well done!",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 175,
                      "angle": 0,
                      "width": 93.45,
                      "height": 78.11,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#000000",
                      "text": "h=${h}\nn=${n}",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 261,
                      "angle": 0,
                      "width": 457.57,
                      "height": 27.12,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#ffffff",
                      "text": "Press space bar to continue.",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "24",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    },
                    {
                      "type": "triangle",
                      "left": "${600*(-0.5+h\u002F(h+n))}",
                      "top": "25",
                      "angle": 0,
                      "width": 34.5,
                      "height": 29.87,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#ffffff"
                    },
                    {
                      "type": "line",
                      "left": -109.32,
                      "top": 0,
                      "angle": 0,
                      "width": 401.83,
                      "height": 0,
                      "stroke": "#d6341a",
                      "strokeWidth": 10,
                      "fill": "rgb(0,0,0)"
                    },
                    {
                      "type": "line",
                      "left": 194.74,
                      "top": 0,
                      "angle": 0,
                      "width": 209.52,
                      "height": 0,
                      "stroke": "#12864e",
                      "strokeWidth": 10,
                      "fill": "rgb(0,0,0)"
                    },
                    {
                      "type": "image",
                      "left": "350",
                      "top": 0,
                      "angle": 0,
                      "width": "50",
                      "height": "49",
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"smiley_small_green.png\"] }"
                    },
                    {
                      "type": "image",
                      "left": "-350",
                      "top": 0,
                      "angle": 0,
                      "width": "50",
                      "height": "49",
                      "stroke": null,
                      "strokeWidth": 0,
                      "fill": "black",
                      "src": "${ this.files[\"frowny_small_red.png\"] }"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {
                    "feedback_bad.png": "embedded\u002F3ff2f25add6008ec63f016a54e0f2692c21bd1264ac2042c6dcdcafc6a3a615f.png",
                    "smiley_small_green.png": "embedded\u002F461ff38348b0701b6add328b041b0d329602f61238f1427d5a0575b0536093d8.png",
                    "frowny_small_red.png": "embedded\u002F75fcaf37aa5bd8004458100177b49f7d494b504f1fe5c8468fad8d2e53937f64.png"
                  },
                  "responses": {
                    "keypress": ""
                  },
                  "parameters": {},
                  "messageHandlers": {
                    "run": function anonymous(
) {
o = 1
}
                  },
                  "title": "Feedback Bar Good",
                  "tardy": true
                }
              ]
            }
          ]
        },
        {
          "type": "lab.canvas.Screen",
          "content": [
            {
              "type": "rect",
              "left": 125,
              "top": -25,
              "angle": 0,
              "width": 1582.18,
              "height": 810.26,
              "stroke": null,
              "strokeWidth": 1,
              "fill": "black"
            },
            {
              "type": "i-text",
              "left": 0,
              "top": -25,
              "angle": 0,
              "width": 791.26,
              "height": 310.25,
              "stroke": "#ffffff",
              "strokeWidth": 0,
              "fill": "#ffffff",
              "text": "You chose the worse response option too often and can therefore \nunfortunately not participate in this experiment.\n\nThis is your prolific completion code:\n\nC1FUS4RE\n\n\n\n",
              "fontStyle": "normal",
              "fontWeight": "normal",
              "fontSize": "24",
              "fontFamily": "sans-serif",
              "lineHeight": 1.16,
              "textAlign": "center"
            }
          ],
          "viewport": [
            800,
            600
          ],
          "files": {},
          "responses": {
            "keypress": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "Kriteriumstest",
          "timeout": "500",
          "tardy": true,
          "skip": "${o == 1}"
        },
        {
          "type": "lab.canvas.Screen",
          "content": [
            {
              "type": "rect",
              "left": 125,
              "top": -25,
              "angle": 0,
              "width": 1582.18,
              "height": 810.26,
              "stroke": null,
              "strokeWidth": 1,
              "fill": "black"
            },
            {
              "type": "i-text",
              "left": 0,
              "top": -25,
              "angle": 0,
              "width": 700.93,
              "height": 310.25,
              "stroke": "#ffffff",
              "strokeWidth": 0,
              "fill": "#ffffff",
              "text": "You chose the worse response option too often and can therefore \nunfortunately not participate in this experiment.\n\nThis is your prolific completion code:\n\nC1FUS4RE\n\n\n\nPress any key to terminate the experiment.",
              "fontStyle": "normal",
              "fontWeight": "normal",
              "fontSize": "24",
              "fontFamily": "sans-serif",
              "lineHeight": 1.16,
              "textAlign": "center"
            }
          ],
          "viewport": [
            800,
            600
          ],
          "files": {},
          "responses": {
            "keypress": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "Kriteriumstest",
          "tardy": true,
          "skip": "${o == 1}"
        },
        {
          "type": "lab.canvas.Screen",
          "content": [
            {
              "type": "rect",
              "left": 125,
              "top": -25,
              "angle": 0,
              "width": 1582.18,
              "height": 810.26,
              "stroke": null,
              "strokeWidth": 1,
              "fill": "black"
            },
            {
              "type": "i-text",
              "left": 0,
              "top": -25,
              "angle": 0,
              "width": 700.93,
              "height": 310.25,
              "stroke": "#ffffff",
              "strokeWidth": 0,
              "fill": "#ffffff",
              "text": "You chose the worse response option too often and can therefore \nunfortunately not participate in this experiment.\n\nThis is your prolific completion code:\n\nC1FUS4RE\n\n\n\nPress any key to terminate the experiment.",
              "fontStyle": "normal",
              "fontWeight": "normal",
              "fontSize": "24",
              "fontFamily": "sans-serif",
              "lineHeight": 1.16,
              "textAlign": "center"
            }
          ],
          "viewport": [
            800,
            600
          ],
          "files": {},
          "responses": {
            "keypress": ""
          },
          "parameters": {},
          "messageHandlers": {
            "run": function anonymous(
) {
var xhr = new XMLHttpRequest();
xhr.open("POST", "/save");
xhr.setRequestHeader("X-CSRFToken", csrf_token);
xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
var d = { "data": study.options.datastore.exportJson()};
xhr.onload = function (data) { window.location.href = '/finish'; }
xhr.send(JSON.stringify(d));
}
          },
          "title": "Kriteriumstest",
          "tardy": true,
          "skip": "${o == 1}"
        }
      ]
    }
  ]
})

// Let's go!
study.run()