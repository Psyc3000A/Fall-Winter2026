To play part 1 of day 1, execute file Day1/grp1_day1_1/experiments/study/index.html in a browser of your choice.

To execute part 2, and parts 1 and 2 of day 2, execute the index.html files in the corresponding directories.
